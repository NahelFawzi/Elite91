<div class="topbar-wrap topbar-style-1 is-light-text">
	<div class="ruby-container">
		<div class="topbar-inner container-inner clearfix">
			<div class="topbar-left">
				<?php get_template_part('templates/header/topbar','info'); ?>
				<?php get_template_part('templates/header/topbar', 'date'); ?>
				<?php get_template_part('templates/header/topbar', 'navigation'); ?>
			</div>
			<div class="topbar-right">
				<?php get_template_part('templates/header/topbar', 'social'); ?>
                <?php get_template_part('templates/header/topbar', 'cart'); ?>
				<?php get_template_part('templates/header/topbar', 'subscribe'); ?>
			</div>
		</div>
	</div>
</div>
