<?php
/**
* Template Name: Fullwidth Page Wide Static Photo
*/
get_header(); ?>
<?php if ( have_posts() ) while ( have_posts() ) : the_post(); 
?>
<?php 
		if (has_post_thumbnail() ):
?>
	<div class="post-thumb clearfix">		
			<figure class="featured-thumbnail thumbnail large">
				<?php the_post_thumbnail( 'full' ); ?>
			</figure>
			<div class="clear"></div>	
</div>
		<?php endif; ?>			
<?php endwhile; ?>
<div class="content-holder clearfix">
	<div class="container">
                <div class="row">
                    <div class="col-md-12" id="content">
<?php get_template_part('title'); ?>
                        <?php get_template_part("loop/loop-page-wide-photo"); ?>
						
                    </div>
                </div>
</div>
</div>
<footer class="footer">
<?php get_template_part('wrapper/wrapper-footer'); ?>
</footer>
<?php get_footer(); ?>