<?php /* Static Name: Search */ ?>
<!-- BEGIN SEARCH FORM -->  
	<div class="sb-search">
						<form class="navbar-form" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" accept-charset="utf-8">
							<input class="sb-search-input" placeholder="<?php echo theme_locals("search_term"); ?>" type="text" value="" name="s">
						</form>
					</div>
<!-- END SEARCH FORM -->