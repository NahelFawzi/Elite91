<?php /* Static Name: 404 */ ?>
<?php echo esc_html__('404', 'buzzblog'); ?>