<?php
/**
* Template Name: Fullwidth Page Box Photo
*/
get_header(); ?>
<div class="content-holder clearfix">
	<div class="container">
          <?php get_template_part('title'); ?>
				<?php if ( is_active_sidebar( 'hs_under_header' ) ) : ?>

				<div class="row">
				<div class="col-md-12">
				<?php dynamic_sidebar("hs_under_header"); ?>
				</div>
				</div>
				
				<?php endif; ?>
                <div class="row main-page">
                    <div class="col-md-12" id="content">
					<article class="post__holder">
                        <?php get_template_part("loop/loop-page"); ?>
						</article>
                    </div>
                </div>
</div>
</div>
<footer class="footer">
<?php get_template_part('wrapper/wrapper-footer'); ?>
</footer>
<?php get_footer(); ?>