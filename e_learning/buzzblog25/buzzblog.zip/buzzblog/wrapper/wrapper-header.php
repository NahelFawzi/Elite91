<?php /* Wrapper Name: Header */ ?>
<?php if (buzzblog_getVariable('header_layout')== 'topleftmenu' && buzzblog_getVariable('header_position')== 'stickyheader') { ?>
<div class="visible-md-block visible-lg-block">
<div class="container">
<div class="row">
    <div class="col-md-12">
        <?php get_template_part("static/static-logo"); ?>
    </div>
</div></div></div>
<?php
}
?>
<?php if (buzzblog_getVariable('header_layout')== 'topleftmenu' && buzzblog_getVariable('header_position')!= 'stickyheader') { ?>
<div class="visible-md-block visible-lg-block">
<div class="row">
    <div class="col-md-12">
        <?php get_template_part("static/static-logo"); ?>
    </div>
</div></div>
<?php
}
?>
<?php
if (buzzblog_getVariable('header_layout')== 'center' && buzzblog_getVariable('header_position')!= 'stickyheader') {
?>
<div class="visible-md-block visible-lg-block">
<div class="row">
    <div class="col-md-12">
        <?php get_template_part("static/static-logo"); ?>
    </div>
</div>
<div class="row">
	<div class="col-md-12">
    	<?php get_template_part("static/static-nav"); ?>
    </div>
</div>
</div>
<?php
}
?>
<?php

if (buzzblog_getVariable('header_layout')== 'center' && buzzblog_getVariable('header_position')== 'stickyheader' or buzzblog_getVariable('header_layout')== '') {
wp_enqueue_script('buzzblog-AnimatedHeader');

?>
<div class="visible-md-block visible-lg-block">
<div class="container">
<div class="row">
    <div class="col-md-12">
        <?php get_template_part("static/static-logo"); ?>
    </div>
</div>
</div>
<div class="sticky-wrapper"><div class="sticky-nav">
<div class="container">
<div class="row">
	<div class="col-md-12">
    	<?php get_template_part("static/static-nav"); ?>
    </div>
</div></div></div></div></div>
<?php
}
?>
<?php
if (buzzblog_getVariable('header_layout')== 'topcenter' && buzzblog_getVariable('header_position')!= 'stickyheader') {
?>
<div class="visible-md-block visible-lg-block">
<div class="row">
	<div class="col-md-12 topcenter ">
    	<?php get_template_part("static/static-nav"); ?>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <?php get_template_part("static/static-logo"); ?>
    </div>
</div>
</div>
<?php
}
?>
<?php
if (buzzblog_getVariable('header_layout')== 'topcenter' && buzzblog_getVariable('header_position')== 'stickyheader') {
wp_enqueue_script('buzzblog-AnimatedHeader');

?>
<div class="visible-md-block visible-lg-block">
<div class="sticky-wrapper"><div class="sticky-nav"><div class="container">
<div class="row">
	<div class="col-md-12 topcenter">
    	<?php get_template_part("static/static-nav"); ?>
    </div>
</div></div></div></div>
<div class="container">
<div class="row">
    <div class="col-md-12">
        <?php get_template_part("static/static-logo"); ?>
    </div>
</div>
</div>
</div>
<?php
}
?>
<?php
if (buzzblog_getVariable('header_layout')== 'left' && buzzblog_getVariable('header_position')!= 'stickyheader') { 
?>
<div class="top-bar top-left-menu-container visible-md-block visible-lg-block">
<div class="row top-right-menu">
<div class="col-md-12 col-sm-12 col-xs-12 top-left">
	<?php
get_template_part("static/static-nav");
?>
  <div class="logo-left">
        <?php get_template_part("static/static-logo"); ?>
    </div>
</div>
</div>
</div>

<?php
}
?>
<?php
if (buzzblog_getVariable('header_layout')== 'left' && buzzblog_getVariable('header_position')== 'stickyheader') { 
wp_enqueue_script('buzzblog-AnimatedHeader');

?>
<div class="top-bar top-left-menu-container visible-md-block visible-lg-block">
<div class="sticky-wrapper"><div class="sticky-nav"><div class="container">
<div class="row top-right-menu">
<div class="col-md-12 col-sm-12 col-xs-12 top-left">
	<?php
get_template_part("static/static-nav");
?>
  <div class="logo-left">
        <?php get_template_part("static/static-logo"); ?>
    </div>
</div>

</div></div></div></div></div>

<?php
}
?>
<?php
if (buzzblog_getVariable('header_layout')== 'leftad' && buzzblog_getVariable('header_position')== 'stickyheader') {
wp_enqueue_script('buzzblog-AnimatedHeader');

?>
<div class="top-bar top-left-menu-container visible-md-block visible-lg-block">
<div class="container">
<div class="top-ads-container">
<div class="row">
    <div class="col-sm-3 col-md-3">
         <div class="logo-ads-left">
        <?php get_template_part("static/static-logo"); ?>
    </div>
    </div>
	    <div class="col-sm-9 col-md-9">
         <div class="right-ads">
        <?php dynamic_sidebar("hs_ads"); ?>
    </div>
    </div>
</div></div>
</div>
<div class="sticky-wrapper"><div class="sticky-nav"><div class="container">
<div class="row ads-below-menu">
<div class="col-md-12 col-sm-12 col-xs-12 top-left">
	<?php
get_template_part("static/static-nav");
?>
</div>
</div></div></div></div></div>
<?php
}

if (buzzblog_getVariable('header_layout')== 'leftad' && buzzblog_getVariable('header_position')!= 'stickyheader') {
?>
<div class="top-bar top-left-menu-container visible-md-block visible-lg-block">

<div class="top-ads-container">
<div class="row">
    <div class="col-sm-3 col-md-3">
         <div class="logo-ads-left">
        <?php get_template_part("static/static-logo"); ?>
    </div>
    </div>
	    <div class="col-sm-9 col-md-9">
         <div class="right-ads">
        <?php dynamic_sidebar("hs_ads"); ?>
    </div>
    </div>
</div></div>
<div class="row ads-below-menu">
<div class="col-md-12 col-sm-12 col-xs-12 top-left">
	<?php
get_template_part("static/static-nav");
?>

</div>

</div></div>
<?php
}
?>