<?php
if(buzzblog_getVariable('featured_images') =='featured3') {
}else{
if(!is_singular() && buzzblog_getVariable('featured_images') =='featured2' || !is_singular() && buzzblog_getVariable('featured_images') =='featured1') { 
?>
		<?php if(has_post_thumbnail()) { ?>
		<?php if(has_post_format('image')) { 
		$src = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'full', false, '' );
		?>
				<div class="thumb-container">
				<figure class="featured-thumbnail thumbnail large">
				<?php buzzblog_pinterest_share(); ?>
				<a class="image-wrap image-popup-no-margins" href="<?php echo esc_url($src[0]); ?>" title="<?php esc_attr(the_title()); ?>">
				<?php the_post_thumbnail( 'buzzblog-standard-large' ); ?> 
				<span class="zoom-icon"></span>	
				</a>
				</figure></div>
		<?php }else{ ?>
		<div class="thumb-container">
				<figure class="featured-thumbnail thumbnail large">
				<?php buzzblog_pinterest_share(); ?>
				<a href="<?php esc_url(the_permalink()); ?>" title="<?php esc_attr(the_title()); ?>">
				<?php the_post_thumbnail( 'buzzblog-standard-large' ); ?> 
				</a>
				</figure></div>
		<?php }} ?>

<?php } ?>

<?php if(is_singular() && buzzblog_getVariable('featured_images') =='featured1') { ?>

	<?php if(has_post_thumbnail()) { ?>
	<div class="thumb-container">
<figure class="featured-thumbnail thumbnail large">
				<?php buzzblog_pinterest_share(); ?>
				<?php the_post_thumbnail( 'buzzblog-standard-large' ); ?> 
				
				</figure></div>
<?php
   }
 } 
}
?>

