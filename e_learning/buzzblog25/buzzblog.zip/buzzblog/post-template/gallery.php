<?php 
$buzzblog_gallery_featured = get_post_meta(get_the_ID(), 'buzzblog_gallery_featured', true);

if (($buzzblog_gallery_featured=='true' && is_singular()) or ($buzzblog_gallery_featured=='false')) { 
$buzzblog_targetheight = get_post_meta(get_the_ID(), 'buzzblog_gallery_targetheight', true);
$buzzblog_gallery_margins = get_post_meta(get_the_ID(), 'buzzblog_gallery_margins', true);
$buzzblog_gallery_captions = get_post_meta(get_the_ID(), 'buzzblog_gallery_captions', true);
$buzzblog_gallery_randomize = get_post_meta(get_the_ID(), 'buzzblog_gallery_randomize', true);
$buzzblog_gallery_type = get_post_meta(get_the_ID(), 'buzzblog_gallery_format', true);
$buzzblog_random = buzzblog_gener_random(10);
if ($buzzblog_gallery_type!='slideshow' && $buzzblog_gallery_type!='grid') {echo esc_html__('Select the gallery type', 'buzzblog');}
	 if ($buzzblog_gallery_type=='slideshow') { 
			$args = array(
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
			'post_type'      => 'attachment',
			'post_parent'    => get_the_ID(),
			'post_mime_type' => 'image',
			'post_status'    => null,
			'numberposts'    => -1,
		);
		$attachments = get_post_meta( $post->ID, '_format_gallery_images', true );
		if ($attachments) {  
		$c = 0;
		foreach ($attachments as $attachment) { 
		if ( wp_attachment_is_image( $attachment ) ) $c++; 
		}
	 ?>
		<!-- Slider -->
		<div class="carousel-wrap">
			<div id="owl-carousel-<?php echo esc_attr( $buzzblog_random) ?>" class="owl-carousel" data-howmany="<?php echo esc_attr($c); ?>" data-margin="25" data-items="1" data-tablet="1" data-mobile="1"  data-auto-play="true" data-auto-play-timeout="5000" data-nav="true" data-rtl="<?php if (is_rtl()) { echo esc_attr('true'); }else{ echo esc_attr('false');} ?>" data-pagination="false">
					<?php
							
								foreach ($attachments as $attachment) {
								
									$attachment_url = wp_get_attachment_image_src( $attachment, 'buzzblog-standard-large' );
									$url            = $attachment_url[0];
									$image          = aq_resize($url, 1080, 600, true, true, true);
									$caption = get_post_field('post_excerpt', $attachment);
							?>
							<div class="featured-thumbnail thumbnail large"><img src="<?php echo esc_url($image); ?>" width="<?php echo esc_attr($attachment_url[1]); ?>" height="<?php echo esc_attr($attachment_url[2]); ?>" alt="<?php echo esc_attr($caption); ?>" /><?php if ($caption !='') { ?><div class="slideshow-cap"><?php echo esc_attr($caption); ?></div><?php } ?></div>
								<?php }; ?>
			</div></div>
			<!-- /Slider -->
	
		<?php }else{echo esc_html__('No images', 'buzzblog');}
		} ?>
		
		<!-- Grid -->
		<?php if ($buzzblog_gallery_type=='grid') {
					$args_hs = array(
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
			'post_type'      => 'attachment',
			'post_parent'    => get_the_ID(),
			'post_mime_type' => 'image',
			'post_status'    => null,
			'numberposts'    => -1,
		);

		$buzzblog_attachments = get_post_meta( $post->ID, '_format_gallery_images', true ); 
		if ($buzzblog_attachments) {
		?>

					<div id="justifiedgall_<?php echo esc_attr( $buzzblog_random) ?>" data-captions="<?php if( ! empty( $buzzblog_gallery_captions ) ) {echo esc_attr( $buzzblog_gallery_captions);}else{echo 'true';} ?>" data-rowheight="<?php if( ! empty( $buzzblog_targetheight ) ) {echo esc_attr( $buzzblog_targetheight);}else{echo '150';} ?>" data-margins="<?php if( ! empty( $buzzblog_gallery_margins ) ) {echo esc_attr( $buzzblog_gallery_margins);}else{echo '10';} ?>" data-randomize="<?php if( ! empty( $buzzblog_gallery_randomize ) ) {echo esc_attr( $buzzblog_gallery_randomize);}else{echo 'false';} ?>">
		
					<?php 
					foreach ($buzzblog_attachments as $attachment) {
									$attachment_url = wp_get_attachment_image_src( $attachment, 'buzzblog-post-gallery-tall' );
									$attachment_full = wp_get_attachment_image_src( $attachment, 'full' );
									$url            = $attachment_url[0];
							
			$caption = get_post_field('post_excerpt', $attachment);
					?>
					
					<a title="<?php echo esc_attr($caption); ?>" href="<?php echo esc_url($attachment_full['0']); ?>"><img src="<?php echo esc_url($url); ?>" width="<?php echo esc_attr($attachment_url[1]); ?>" height="<?php echo esc_attr($attachment_url[2]); ?>" alt="<?php echo esc_attr($caption); ?>"/></a>
					<?php 
						}
					?>
			</div>

		<?php }else{echo esc_html__('No images', 'buzzblog');} }?>
		<!-- /Grid -->
<?php }

 if ($buzzblog_gallery_featured=='true' && !is_singular() && (buzzblog_getVariable('blog_sidebar_pos')=='masonry2' or buzzblog_getVariable('blog_sidebar_pos')=='masonry3' or buzzblog_getVariable('blog_sidebar_pos')=='masonry4' or buzzblog_getVariable('blog_sidebar_pos')=='masonry2sideright' or buzzblog_getVariable('blog_sidebar_pos')=='masonry2sideleft')) {  get_template_part('post-template/post-thumb'); } ?>