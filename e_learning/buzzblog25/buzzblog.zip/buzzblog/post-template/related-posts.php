<?php
$categories = get_the_category($post->ID);
if ($categories) {
$category_ids = array();
foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
$args=array(
'category__in' => $category_ids,
'post__not_in' => array($post->ID),
'showposts' => 3
); 

	// WP_Query takes the same arguments as query_posts
	$related_query = new WP_Query($args);

	if ($related_query->have_posts()) {	?>
	<div class="related-posts"><div class="related-content">

			<h5 class="related-posts_h"><span><?php echo theme_locals("blog_related"); ?></span></h5>
		
			<div class="row">

				<?php
				while ($related_query->have_posts()) : $related_query->the_post();
				$thumb = get_post_thumbnail_id();
				$img_url = wp_get_attachment_url($thumb,'full');
				$img_width = 726;
				$img_height = 440;
				$img = aq_resize( $img_url, $img_width, $img_height, true, true, true );
				?>
					<div class="col-sm-4 col-md-4 col-lg-4">
					
					<div class="hercules-related-default" style="<?php if($img) {echo 'background-image:url('.esc_url($img).');';} ?>">
					<a href="<?php esc_url(the_permalink()); ?>" title="<?php esc_attr(the_title()); ?>" class="hercules-related-default-link"></a>
					</div>
						
						<div class="related-list-inner">
						<h6><a href="<?php esc_url(the_permalink()) ?>" > <?php esc_attr(the_title());?> </a></h6>
	<?php if (buzzblog_getVariable('post_date')=='yes' or buzzblog_getVariable('post_date')=='') {buzzblog_entry_date();} ?>
						</div>
					</div>
				<?php
				endwhile;
				?>
			</div>
	</div></div><!-- .related-posts -->
	<?php }
	wp_reset_postdata();
} ?>