<?php
if( ! class_exists( 'buzzblog_slideshowClass' ) ) {
class buzzblog_slideshowClass
{
public static function buzzblog_slideshow()
  {
wp_enqueue_script('buzzblog-owljs');
wp_enqueue_style( 'buzzblog-owl' );

global $buzzblog_options;

$ids = (isset($buzzblog_options['posts_by_id']) ? $buzzblog_options['posts_by_id'] : null);
$categories = (isset($buzzblog_options['posts_by_cat']) ? $buzzblog_options['posts_by_cat'] : null);

			$post_type = 'post';
			$post_status = 'publish';
			
			$custom_class  = '';
			$rtl_slide = '';
			
		$random_ID          = uniqid();
		$number_of_posts        = intval(buzzblog_getVariable('howmany_slides'));
		$thumb              = 'true';
		$thumb_width        = absint( buzzblog_getVariable('slideshow_thumbwidth') );
		$thumb_height       = absint( buzzblog_getVariable('slideshow_thumbheight') );
		$number_of_words      = absint( buzzblog_getVariable('slideshow_excerpt_words') );
		$items_desktop   = absint( buzzblog_getVariable('howmany_desktop') );
		$items_tablet   = absint( buzzblog_getVariable('howmany_tablet') );
		$items_mobile   = absint( buzzblog_getVariable('howmany_mobile') );
		$margin   = absint( buzzblog_getVariable('slideshow_margin') );
		$autoplay             = buzzblog_getVariable('slideshow_autoplay')== 'yes' ? 'true' : 'false';
		$auto_play_timeout          = absint( buzzblog_getVariable('slideshow_pause') );
		$date               = buzzblog_getVariable('slideshow_date') == 'yes' ? true : false;
		$author             = buzzblog_getVariable('slideshow_author')== 'yes' ? true : false;
		$show_category             = buzzblog_getVariable('slideshow_cat_name')== 'yes' ? true : false;
		$view_post_button             = buzzblog_getVariable('slideshow_viewpost')== 'yes' ? true : false;
		$display_navs       = buzzblog_getVariable('slideshow_displaynavs')== 'yes' ? 'true' : 'false';
		
		$display_pagination = buzzblog_getVariable('slideshow_displaypagination')== 'yes' ? 'true' : 'false';
		$itemcounter = 0;
if (is_rtl()) {$rtl_slide = 'true';}
		switch ( strtolower( str_replace(' ', '-', $post_type) ) ) {
			case 'post':
				$post_type = 'post';
				break;
			case 'gallery':
				$post_type = 'gallery';
				break;
		}

		$suppress_filters = get_option('suppress_filters'); // WPML filter

		// WP_Query arguments

if (!empty($ids)) {

		$args = array(
            'post__in' => $ids,	
            'orderby'  => 'post__in',			
			'post_status'         => $post_status,
			'posts_per_page'      => $number_of_posts,
			'ignore_sticky_posts' => 1,
			'post_type'           => $post_type,
			'meta_key' => '_thumbnail_id',
			'suppress_filters'    => $suppress_filters
		);
}else{
		$args = array(	
'category__in' => $categories,
'orderby'  => 'category__in',
			'post_status'         => $post_status,
			'posts_per_page'      => $number_of_posts,
			'ignore_sticky_posts' => 1,
			'post_type'           => $post_type,
			'meta_key' => '_thumbnail_id',
			'suppress_filters'    => $suppress_filters
		);
		}
		// The Query
		$carousel_query = new WP_Query( $args );
		$output = '';

		if ( $carousel_query->have_posts() ) :

			echo '<div  class="carousel-wrap slideshow ' . esc_attr($custom_class) . '">';
				echo '<div id="owl-carousel-' . esc_attr($random_ID) . '" class="owl-carousel-' . esc_attr($post_type) . ' owl-carousel" data-howmany="' .esc_attr($number_of_posts). '" data-margin="' . esc_attr($margin) . '" data-items="' . esc_attr($items_desktop) . '" data-tablet="' . esc_attr($items_tablet) . '" data-mobile="' . esc_attr($items_mobile) . '"  data-auto-play="' . esc_attr($autoplay) . '" data-auto-play-timeout="' . esc_attr($auto_play_timeout) . '" data-nav="' . esc_attr($display_navs) . '" data-rtl="'.esc_attr($rtl_slide).'" data-pagination="' . esc_attr($display_pagination) . '">';

				while ( $carousel_query->have_posts() ) : $carousel_query->the_post();
					$post_id         = $carousel_query->post->ID;
					$post_title      = get_the_title( $post_id );
					$post_categories = get_the_category( $post_id );
					$post_title_attr = esc_attr( strip_tags( get_the_title( $post_id ) ) );
					$format          = get_post_format( $post_id );
					$format          = (empty( $format )) ? 'format-standart' : 'format-' . $format;
					if ( get_post_meta( $post_id, 'buzzblog_link_url', true ) ) {
						$post_permalink = ( $format == 'format-link' ) ? esc_url( get_post_meta( $post_id, 'buzzblog_link_url', true ) ) : get_permalink( $post_id );
					} else {
						$post_permalink = get_permalink( $post_id );
					}
					if ( has_excerpt( $post_id ) ) {
						$excerpt = get_the_excerpt();
					} else {
						$excerpt = get_the_content();
					}

					echo '<div style="position:relative;" class="item_' . esc_attr($format) . ' item-list-'.esc_attr($itemcounter).'">';
echo '<div style="position:relative;z-index:3;width: 100%;height: 100%;">';
						// post thumbnail
						if ( $thumb ) :

							if ( has_post_thumbnail( $post_id ) ) {
				
									$attachment_url = get_post_thumbnail_id();
									$url            = wp_get_attachment_url( $attachment_url);
								$image          = aq_resize($url, $thumb_width, $thumb_height, true, true, true);
									
								echo '<figure style="visibility: hidden;position:relative;">';
									echo '<a href="' . esc_url($post_permalink) . '" title="' . esc_attr($post_title) . '">';
										echo '<img src="' . esc_url($image) . '" width="' . esc_attr($thumb_width) . '" height="' . esc_attr($thumb_height) . '" alt="' . esc_attr($post_title) . '" />';
									echo '</a>';
								echo '</figure>';
								echo '<div style="position:absolute;top:0;background-position: center;background-size: cover;background-repeat: no-repeat;width: 100%;height: 100%;" class="owl-lazy" data-src="' . esc_url($image) . '" data-src-retina="' . esc_url($url) . '"  ></div>';

							}
echo '</div>';
						endif;

						echo '<div class="slideshow-desc">';
echo '<div class="slideshow-container">';
echo '<div class="slideshow-box">';
echo '<div class="slideshow-desc-box">';
							
if ( ! empty( $post_categories )  ) {   
echo esc_attr( $show_category) ? '<div class="slide-category"><a class="carousel-category" href="' . esc_url( get_category_link( $post_categories[0]->term_id ) ) . '">' . esc_html( $post_categories[0]->name ) . '</a></div>' : '';
}
							// post title
							if ( !empty($post_title{0}) ) {
								echo '<h2 class="carouselheading"><a href="' . esc_url($post_permalink) . '" title="' . esc_attr($post_title_attr) . '">';
									echo esc_html($post_title_attr);
								echo '</a></h2>';
							}
							echo '<div style="display:block;">';
// post date
							echo esc_attr( $date) ? '<span class="post-date date">' . the_time(buzzblog_getVariable('date_format')) . '</span>' : '';

							// post author
							echo esc_attr( $author) ? '<span class="author"><span>' . esc_html__(', by', 'buzzblog') . ' </span><a href="' . get_author_posts_url( get_the_author_meta( 'ID' ) ).'">' . get_the_author_meta( 'display_name' ) . '</a> </span>' : '';
							echo '</div>';
							// post excerpt
							if ( !empty($excerpt{0}) ) {
								echo esc_attr( $number_of_words) > 0 ? '<div class="excerpt">'.buzzblog_limit_text( $excerpt, $number_of_words ).'</div>' : '';
							}
							// post more button
								echo esc_attr( $view_post_button) ? '<a href="' . esc_url(get_permalink( $post_id )) . '" class="btn btn-default btn-normal" title="' . esc_attr($post_title_attr) . '">' . theme_locals("view_post") . '</a>' : '';

							
						echo '</div></div></div></div>';
					echo '</div>';
					$itemcounter++;
				endwhile;
			echo '</div></div>';
		endif;
		// Restore original Post Data
wp_reset_postdata();
}
}
}
?>