<?php $url =  get_post_meta(get_the_ID(), 'buzzblog_post_link', true);

$thumb = get_post_thumbnail_id();
$img_url = wp_get_attachment_url( $thumb,'full'); //get img URL
	
if ($url): ?>
			<div class="link-image clearfix">
			<a target="_blank" href="<?php echo esc_url($url); ?>" title="<?php echo theme_locals('permalink_to');?> <?php echo esc_url($url); ?>">
		<div class="image-link">	
	<div class="image-background" style="background: url('<?php if (has_post_thumbnail() ): echo esc_url($img_url); endif; ?>') no-repeat scroll 0% 0% transparent; width: 100%; height: 100%;"></div>
	</div>
	<p><span class="responsive wtext">
       <?php echo esc_url($url); ?>
    </span></p>
	</a>
	</div>
	<div class="clear"></div>
<?php endif; ?>
<?php the_content(); ?>