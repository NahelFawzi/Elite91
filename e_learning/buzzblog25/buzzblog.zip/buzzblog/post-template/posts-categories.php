<?php
if ( buzzblog_getVariable('folio_filter') != 'none') {
?>
<div class="archive_lists">
<div class="row category-filter">
<div class="col-md-4 col-sm-4 col-xs-4" >

	<form id="category-select" class="category-select" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">

		<?php
		$args = array(
			'show_option_none' => esc_html__( 'Select category', 'buzzblog' ),
			'show_count'       => 1,
			'orderby'          => 'name',
			'echo'             => 0,
		);
		?>

		<?php $select  = wp_dropdown_categories( $args ); ?>
		<?php $replace = "<select$1 style=\"width: 100%;\" onchange='return this.form.submit()'>"; ?>
		<?php $select  = preg_replace( '#<select([^>]*)>#', $replace, $select ); ?>

		<?php echo balanceTags($select); ?>


	</form>
</div>
<div class="col-md-4 col-sm-4 col-xs-4" >

				<select style="width: 100%;" name="archive-dropdown" onchange="document.location.href=this.options[this.selectedIndex].value;">
  <option value=""><?php esc_html_e('Select Month', 'buzzblog'); ?></option> 
  <?php wp_get_archives( array( 'type' => 'monthly', 'format' => 'option', 'show_post_count' => 1 ) ); ?>
</select>
</div>
<div class="col-md-4 col-sm-4 col-xs-4" >
<?php get_search_form(); ?>
</div>
</div>
</div>
<?php } ?>



                   


 
						
						
						
					
