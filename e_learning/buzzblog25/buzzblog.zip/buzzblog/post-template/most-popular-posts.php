<?php
$args=array(
			'orderby' => 'meta_value_num',
			'order' => 'DESC',
			'meta_key' => '_hercules_likes',
			'showposts' => 4, // these are the number of most commented posts we want to display
			'ignore_sticky_posts' => 1 // to exclude the sticky post
		);
$counter = 1;
	$most_commented = new WP_Query($args);

	if ($most_commented->have_posts()) {	?>
	<div class="most-commented-section"><div class="most-commented-content">

			<h5 class="most-commented-posts"><span><?php echo theme_locals("most_popular"); ?></span></h5>
		
			<div class="row">

				<?php
				while ($most_commented->have_posts()) : $most_commented->the_post();
				$thumb = get_post_thumbnail_id();
				$img_url = wp_get_attachment_url( $thumb,'full');
				$img_width = 340;
				$img_height = 320;
				$img = aq_resize( $img_url, $img_width, $img_height, true, true, true );
				?>
				
					<div class="col-xs-6 col-sm-3 col-md-3 col-lg-3">
					<header class="post-header">
						
									<?php if(has_post_thumbnail()) { ?>

							<figure class="featured-thumbnail thumbnail large">
								<a href="<?php esc_url(the_permalink()); ?>" title="<?php esc_attr(the_title()); ?>"><img src="<?php echo esc_url($img); ?>" width="<?php echo esc_attr($img_width); ?>" height="<?php echo esc_attr($img_height); ?>" alt="<?php esc_attr(the_title());?>" /></a>
							</figure>
						<?php } ?>
											<div class="most-commented-text-container">
											<div class="meta-space-top">

		<h4><?php echo '0'.$counter; ?></h4>
		<?php if (buzzblog_getVariable('post_date')=='yes' or buzzblog_getVariable('post_date')=='') {buzzblog_entry_date();} ?>
		</div>
					<h5 class="post-title"><a href="<?php esc_url(the_permalink()); ?>" title="<?php esc_attr(the_title()); ?>"><?php esc_attr(the_title()); ?></a></h5>

				
			<div class="most-commented-excerpt">			
			<?php 
				$content = get_the_content();
				echo buzzblog_limit_text($content,6);
			 ?>			
			</div></div>
		
			</header>
					</div>

				<?php
				$counter ++ ;
				endwhile;
				?>
			</div>
	</div></div><!-- most-commented-posts -->
	<?php 
	wp_reset_postdata();
	}
 ?>