<?php
$social_share = buzzblog_getVariable('social_share');
$shareon = buzzblog_getVariable('shareon');
$facebook_share = buzzblog_getVariable('facebook_share');
$twitter_share = buzzblog_getVariable('twitter_share');
$twitter_username = buzzblog_getVariable('hs_twitter_username');
$gplus_share = buzzblog_getVariable('gplus_share');
$pinterest_share = buzzblog_getVariable('pinterest_share');
$tumblr_share = buzzblog_getVariable('tumblr_share');
$email_share = buzzblog_getVariable('email_share');
$vkontakte_share = buzzblog_getVariable('vkontakte_share');
$whatsapp_share = buzzblog_getVariable('whatsapp_share');
if ($social_share=='yes') {
?>
<?php if ($shareon=='yes') { ?><span class="shareon"><?php echo theme_locals("share_on"); ?></span><?php } ?>
<div class="share-buttons">
	<?php
		/* get permalink */
		$permalink = get_permalink(get_the_ID());
		$titleget = wp_strip_all_tags(get_the_title());
	?>

<?php
if ($facebook_share=='yes') { ?>
<a class="hs-icon hs hs-facebook" onClick="window.open('http://www.facebook.com/sharer.php?u=<?php echo esc_url( $permalink);?>','Facebook','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://www.facebook.com/sharer.php?u=<?php echo esc_url( $permalink);?>"></a>
<?php } ?>
<?php
if ($twitter_share=='yes') { ?> 
<a class="hs-icon hs hs-twitter" onClick="window.open('http://twitter.com/share?url=<?php echo esc_url( $permalink); ?>&amp;text=<?php echo str_replace(" ", "%20", $titleget); ?><?php if ($twitter_username!='') { echo esc_attr( '&amp;via='.$twitter_username);} ?>','Twitter share','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://twitter.com/share?url=<?php echo esc_url( $permalink); ?>&amp;text=<?php echo str_replace(" ", "%20", $titleget); ?><?php if ($twitter_username!='') { echo esc_attr( '&amp;via='.$twitter_username);} ?>"></a>
<?php } ?>
<?php
if ($gplus_share=='yes') { ?>
<a class="hs-icon hs hs-gplus" onClick="window.open('https://plus.google.com/share?url=<?php echo esc_url( $permalink); ?>','Google plus','width=585,height=666,left='+(screen.availWidth/2-292)+',top='+(screen.availHeight/2-333)+''); return false;" href="https://plus.google.com/share?url=<?php echo esc_url( $permalink); ?>"></a>
<?php } ?>
<?php if ($pinterest_share=='yes') { $pinterestimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); ?>
<a target="_blank" class="hs-icon hs hs-pinterest" href="http://pinterest.com/pin/create/button/?url=<?php echo esc_url( $permalink); ?>&amp;media=<?php echo esc_attr($pinterestimage[0]); ?>&amp;description=<?php echo str_replace(" ", "%20", $titleget); ?>" data-pin-do="buttonPin" data-pin-custom="true"></a>
<?php } ?>
<?php
if ($tumblr_share=='yes') {
$str = $permalink;
$str = preg_replace('#^https?://#', '', $str);
?>
<a class="hs-icon hs hs-tumblr" onClick="window.open('http://www.tumblr.com/share/link?url=<?php echo esc_attr($str); ?>&amp;name=<?php echo str_replace(" ", "%20", $titleget); ?>','Tumblr','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://www.tumblr.com/share/link?url=<?php echo esc_attr($str); ?>&amp;name=<?php echo str_replace(" ", "%20", $titleget); ?>"></a>
<?php } ?>
<?php
if ($vkontakte_share=='yes') { ?>
<a class="hs-icon hs hs-vk" onclick="window.open('http://vk.com/share.php?url=<?php echo esc_url( $permalink);?>','vkontakte','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://vk.com/share.php?url=<?php echo esc_url( $permalink);?>"></a>
<?php } ?>
<?php
if ($whatsapp_share=='yes') { ?>
<a class="hs-icon hs hs-whatsapp visible-xs-inline-block" href="whatsapp://send?text=<?php echo str_replace(" ", "%20", $titleget).'-'.esc_url( $permalink); ?>" data-action="share/whatsapp/share"></a>
<?php } ?>
<?php
if ($email_share=='yes') { ?>
<a class="hs-icon hs hs-mail" href="mailto:?subject=<?php echo str_replace(" ", "%20", $titleget); ?>&amp;body=<?php echo esc_url( $permalink); ?>"></a>
<?php } ?>
</div><!-- //.share-buttons -->
<?php } ?>