<?php
$sticky = get_option( 'sticky_posts' );
$args = array(
	'posts_per_page'      => 1,
	'post__in'            => $sticky,
	'ignore_sticky_posts' => 1,
	'post_type' => 'post'
);
// The Query
$query1 = new WP_Query( $args );

if(isset($sticky[0]) && !$paged){

// The Loop
while ( $query1->have_posts() ) {
	$query1->the_post(); 	
?>
<!-- #first post -->

<div class="row"><div id="post-<?php the_ID(); ?>" <?php post_class('col-sm-12'); ?> >

<?php get_template_part( 'content' ); ?>
	
</div></div><!-- #first post -->
<?php	
}
}
wp_reset_postdata();
?>