<blockquote> <?php the_content(); ?></blockquote>
	
