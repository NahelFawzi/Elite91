<?php get_header(); ?>

<div class="content-holder clearfix">
	<div class="container">
<?php get_template_part('title'); ?>
				     <div class="row main-page">   
                    <div class="col-md-12 content" id="content">
					<main id="main" class="site-main" role="main">
                        <?php get_template_part("loop/loop-main-page"); ?>
					</main>
                    </div>
                      </div>
	</div>
</div>
<footer class="footer">
<?php get_template_part('wrapper/wrapper-footer'); ?>
</footer>
<?php get_footer(); ?>