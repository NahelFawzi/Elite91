<div id="hs_signup" class="zoom-anim-dialog mfp-hide" data-showonload="<?php if(buzzblog_getVariable('newsletter-cookie-onload') =='yes') { echo 'true';}else{echo 'false';} ?>"><div id="hs_signup_inner">
<?php echo do_shortcode(htmlspecialchars_decode(buzzblog_getVariable( 'newsletter-text' ))) ; ?>
</div></div>