<?php
/**
* Template Name: Fullwidth Page Wide Parallax Photo
*/
get_header(); ?>
<?php if ( have_posts() ) while ( have_posts() ) : the_post(); 
?>
<?php 
		if (has_post_thumbnail() ):
?>

<?php $buzzblog_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>
<div class="parallax-image" data-stellar-background-ratio="0.5" data-stellar-horizontal-offset="0" data-stellar-vertical-offset="0" style="background:url(<?php echo esc_url($buzzblog_feat_image);?>);position:relative;text-align: center;background-repeat:no-repeat;background-size: cover;">
<div class="header-overlay"></div>
<div class="container"><div class="row">
                    <div class="col-md-12" id="content">
					<?php $buzzblog_page_title = get_post_meta( get_the_ID(), 'buzzblog_page_title_enable', true );
					if($buzzblog_page_title == esc_html__('enable','buzzblog')){
					?>
					<section class="title-section" style="margin: 140px auto;padding: 0 40px 0 40px;">
				<?php
					 $buzzblog_title = get_post_meta( get_the_ID(), 'buzzblog_page_tit', true );
$buzzblog_subtitle = get_post_meta( get_the_ID(), 'buzzblog_page_sub', true );
					if($buzzblog_title == ""){ ?>
						<h1><?php esc_attr(the_title()); ?></h1>
						<?php
					} else { ?>
						<h1><?php echo esc_attr($buzzblog_title); ?></h1>
					<?php
					}
					if($buzzblog_subtitle != ""){ ?>
						<span class="title-desc"></span><h2><?php echo esc_attr($buzzblog_subtitle);?></h2>
						
					<?php } ?>
					</section>
					<?php }else{ ?>
					<section class="title-section" style="margin: 40px auto;">
					<h1><?php esc_attr(the_title()); ?></h1>
					</section>
					<!-- .title-section -->
					<?php } ?>
					</div>
                </div></div>
</div>
		<?php endif; ?>		
<?php if (!has_post_thumbnail() ): ?>
 <div class="content-holder clearfix">
	<div class="container">
	<div class="row">
                    <div class="col-md-12" id="content">
					<section class="title-section">
					<h1><?php esc_attr(the_title()); ?></h1>
					</section>
    </div></div></div>
                </div>
 <?php endif; ?>	
<?php endwhile; ?>
<div class="content-holder clearfix">
	<div class="container">
                <div class="row">
                    <div class="col-md-12" id="content">
					
                        <?php get_template_part("loop/loop-page-wide-photo"); ?>
						
                    </div>
                </div>
</div>
</div>
<footer class="footer">
<?php get_template_part('wrapper/wrapper-footer'); ?>
</footer>
<?php get_footer(); ?>