<?php get_header(); ?>
<div class="content-holder clearfix">
	<div class="container">
<?php get_template_part('title'); ?>
				<?php if ( is_active_sidebar( 'hs_under_header' ) ) : ?>

				<div class="row">
				<div class="col-md-12">
				<?php dynamic_sidebar("hs_under_header"); ?>
				</div>
				</div>
				
				<?php endif; ?>
				     <div class="row main-page">
				<?php if (buzzblog_getVariable('page_sidebar_pos')=='right' or buzzblog_getVariable('page_sidebar_pos')=='') { ?>   
                    <div class="col-md-8 content" id="content" role="main">
                       <article class="post__holder"><?php get_template_part("loop/loop-main-page"); ?></article>
                    </div>
                 <div class="col-md-4 sidebar <?php if (buzzblog_getVariable('sidebar_sticky')=='stickysidebar') { echo 'sticky-sidebar'; } ?>" id="sidebar">
                      <div class="theiaStickySidebar">
                        <?php dynamic_sidebar("hs_main_sidebar"); ?>
                    </div></div>
					<?php } ?> 
					<?php if (buzzblog_getVariable('page_sidebar_pos')=='left') { ?>   
                    <div class="col-md-8 col-md-push-4 content" id="content" role="main">
                       <article class="post__holder"><?php get_template_part("loop/loop-main-page"); ?></article>
                    </div>
                 <div class="col-md-4 col-md-pull-8 sidebar <?php if (buzzblog_getVariable('sidebar_sticky')=='stickysidebar') { echo 'sticky-sidebar'; } ?> left" id="sidebar">
                    <div class="theiaStickySidebar">
                        <?php dynamic_sidebar("hs_main_sidebar"); ?>
                    </div></div>
					<?php } ?> 
					<?php if (buzzblog_getVariable('page_sidebar_pos')=='full') { ?>   
                    <div class="col-md-12 content" id="content" role="main">
                        <article class="post__holder"><?php get_template_part("loop/loop-main-page"); ?></article>
                    </div>
					<?php } ?>
                      </div>
	</div>
</div>
<footer class="footer">
<?php get_template_part('wrapper/wrapper-footer'); ?>
</footer>
<?php get_footer(); ?>