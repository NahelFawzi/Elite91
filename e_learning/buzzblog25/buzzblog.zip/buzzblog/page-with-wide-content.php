<?php
/**
* Template Name: Page With Wide Content
*/
get_header(); ?>
<div class="content-holder clearfix">
	<div class="container">
          <?php get_template_part('title'); ?>
				<?php if ( is_active_sidebar( 'hs_under_header' ) ) : ?>
				<div class="row">
				<div class="col-md-12">
				<?php dynamic_sidebar("hs_under_header"); ?>
				</div>
				</div>
				<?php endif; ?>
</div>
</div>
<?php get_template_part("loop/loop-page"); ?>
<footer class="footer">
<?php get_template_part('wrapper/wrapper-footer'); ?>
</footer>
<?php get_footer(); ?>