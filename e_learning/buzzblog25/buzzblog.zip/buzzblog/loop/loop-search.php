<?php /* Loop Name: Loop search */ ?>
<!-- displays the tag's description from the Wordpress admin -->
<?php 
	if (is_tag()) 
		echo tag_description();

	if (have_posts()) : while (have_posts()) : the_post();

	get_template_part( 'content' );
	
		endwhile; else: 

		get_template_part( 'content', 'none' );
	 endif; ?>
<?php get_template_part('post-template/post-nav'); ?>