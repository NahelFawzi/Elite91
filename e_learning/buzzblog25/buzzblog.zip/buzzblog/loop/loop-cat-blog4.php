<?php /* Loop Name: Loop portfolio 4 */ ?>
<?php // Theme Options vars
wp_enqueue_script('masonry');
$cols = '4cols';
$feautered = '';
require get_template_directory() . '/blog-category-masonry-loop.php';