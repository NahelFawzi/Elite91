<?php /* Loop Name: Loop portfolio 2 */ ?>
<?php // Theme Options vars
wp_enqueue_script('masonry');
$cols = '2cols';
$feautered = '';
require get_template_directory() . '/blog-category-masonry-loop.php';