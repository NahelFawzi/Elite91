<?php get_header(); ?>
<div class="content-holder clearfix">
    <div class="container">
	 <div class="spacer"></div>
                 <div class="row">
			   <div class="col-md-12" id="content">
                        <?php get_template_part("loop/loop-single-gallery"); ?>
                    </div>
                </div>
    </div>
</div>
<footer class="footer">
<?php get_template_part('wrapper/wrapper-footer'); ?>
</footer>
<?php get_footer(); ?>

