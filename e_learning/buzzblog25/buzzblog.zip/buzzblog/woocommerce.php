<?php get_header(); ?>
<div class="content-holder clearfix">
	<div class="container">
	<?php if ( !is_singular( 'product' ) ) { ?>
	<section class="title-section">
			<?php
				$buzzblog_blog_text = buzzblog_getVariable('woocommerce_title');
				 if($buzzblog_blog_text){?>
					<h1><?php echo esc_attr( buzzblog_getVariable('woocommerce_title')); ?></h1>
				<?php } ?>
				<?php $hercules_blog_sub = buzzblog_getVariable('woocommerce_subtitle'); ?>
				<?php if($hercules_blog_sub){?>
					<?php echo "<span></span><h2>". esc_attr( buzzblog_getVariable('woocommerce_subtitle') ) . "</h2>"; 	?>
				<?php } ?>
				</section>
					<?php } ?>
				<?php if ( is_active_sidebar( 'hs_under_header' ) ) : ?>

				<div class="row">
				<div class="col-md-12">
				<?php dynamic_sidebar("hs_under_header"); ?>
				</div>
				</div>
				
				<?php endif; ?>
				     <div class="row main-page">
				<?php if (buzzblog_getVariable('woocommerce_sidebar_pos')=='right' or buzzblog_getVariable('woocommerce_sidebar_pos')=='') { ?>   
                    <div class="col-md-8 content" id="content">
                        <?php get_template_part("loop/loop-woocommerce"); ?>
                    </div>
                 <div class="col-md-4 sidebar" id="sidebar">
                        <?php dynamic_sidebar("hs_woocommerce_sidebar"); ?>
                    </div>
					<?php } ?> 
					<?php if (buzzblog_getVariable('woocommerce_sidebar_pos')=='left') { ?>   
                    <div class="col-md-8 col-md-push-4 content" id="content">
                         <?php get_template_part("loop/loop-woocommerce"); ?>
                    </div>
                 <div class="col-md-4 col-md-pull-8 sidebar left" id="sidebar">
                        <?php dynamic_sidebar("hs_woocommerce_sidebar"); ?>
                    </div>
					<?php } ?> 
					<?php if (buzzblog_getVariable('woocommerce_sidebar_pos')=='full') { ?>   
                    <div class="col-md-12 content" id="content">
 <?php get_template_part("loop/loop-woocommerce"); ?>
                    </div>
					<?php } ?>
                      </div>
	</div>
</div>
<footer class="footer">
<?php get_template_part('wrapper/wrapper-footer'); ?>
</footer>
<?php get_footer(); ?>