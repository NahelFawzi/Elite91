<?php
//Woocommerce product per page
function buzzblog_overide_product_count($cols)
{
global $buzzblog_options;
if(isset($buzzblog_options['woocommerce_items_per_page'])) {
				return $buzzblog_options['woocommerce_items_per_page'];
				}
}
add_filter( 'loop_shop_per_page', 'buzzblog_overide_product_count', 20 );
add_filter( 'woocommerce_show_page_title' , 'woo_hide_page_title' );
function woo_hide_page_title() {
	return false;
}
add_action( 'after_setup_theme', 'buzzblog_woocommerce_support' );
function buzzblog_woocommerce_support() {
    add_theme_support( 'woocommerce' );
}
// Change number or products per row to 3
add_filter('loop_shop_columns', 'buzzblog_loop_columns');
if (!function_exists('buzzblog_loop_columns')) {
	function buzzblog_loop_columns() {
		return 3; // 3 products per row
	}
}
function buzzblog_add_buzzblog_cart() {

	wp_register_script( 'buzzblog-menucart', get_template_directory_uri() . '/woocommerce-scripts/js/woocommerce-buzzblog.js', array() , '1.0', 'all');
	wp_enqueue_script( 'buzzblog-menucart' );

}

add_action('wp_enqueue_scripts', 'buzzblog_add_buzzblog_cart');

function buzzblog_get_cart_items() {
	global $woocommerce;

	$articles = sizeof( $woocommerce->cart->get_cart() );


	$cart = $total_articles = '';

	if (  $articles > 0 ) {
		$total_articles = $woocommerce->cart->cart_contents_count;
		foreach ( $woocommerce->cart->get_cart() as $cart_item_key => $cart_item ) {
			$_product     = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
			$product_id   = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

			if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key ) ) {

				$product_name  = apply_filters( 'woocommerce_cart_item_name', $_product->get_title(), $cart_item, $cart_item_key );
				$thumbnail     = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );
				$product_price = apply_filters( 'woocommerce_cart_item_price', $woocommerce->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
                $string = apply_filters( 'woocommerce_get_remove_url', $woocommerce->cart->get_remove_url( $cart_item_key ));
				$cart .= '<li class="cart-item-list clearfix">';
				if ( ! $_product->is_visible() ) {
					$cart .= str_replace( array( 'http:', 'https:' ), '', $thumbnail );
				} else {
					$cart .= '<a class="product-image" href="'.esc_url(get_permalink( $product_id )).'">
								'.str_replace( array( 'http:', 'https:' ), '', $thumbnail ) . '
							</a>';
				}
                $cart .= '<a title="'.esc_html__( 'Remove this item', 'buzzblog' ).'" class="remove" href="'.$string.'"><i class="fa fa-times" aria-hidden="true"></i>
</a>';
				$cart .= '<div class="product-details"><span class="product-name">' . $product_name .'</span>';

				$cart .= '<span class="product-quantity">'. apply_filters( 'woocommerce_widget_cart_item_quantity',  '<span class="quantity-container">' . sprintf( '%s &times; %s',$cart_item['quantity'] , '</span>' . $product_price ) , $cart_item, $cart_item_key ) . '</span>';
				$cart .= '</div>';
				$cart .= '</li>';
			}
		}

		$cart .= '<li class="subtotal"><span class="subtotalwr">' . esc_html__('Estimated total:', 'buzzblog') . '</span><span> ' . $woocommerce->cart->get_cart_total() . '</span></li>';

		$cart .= '<li class="buttons clearfix">
								<a href="'.esc_url($woocommerce->cart->get_cart_url()).'" class="btn btn-default btn-normal"><i class="fa fa-bag"></i>'.esc_html__( 'View Cart', 'buzzblog' ).'</a>
								
							</li>';

	} else {
		$cart .= '<li><span>' . esc_html__('No products in the cart.','buzzblog') . '</span></li>';
	}

	return array('cart' => $cart, 'articles' => $total_articles);
}

function buzzblog_woomenucart_ajax() {

	$cart = buzzblog_get_cart_items();

	echo json_encode($cart);

	die();
}

add_action( 'wp_ajax_woomenucart_ajax', 'buzzblog_woomenucart_ajax');
add_action( 'wp_ajax_nopriv_woomenucart_ajax', 'buzzblog_woomenucart_ajax' );


function buzzblog_add_cart_in_menu($woo_icon) {
	global $woocommerce;

	$total_articles = $woocommerce->cart->cart_contents_count;
	$get_cart_items = buzzblog_get_cart_items();

	$vertical = false;

	$cart_container = '<ul class="sub-menu buzzblog-submenu-cart">'.((isset($get_cart_items['cart']) && $get_cart_items['cart'] !=='') ? $get_cart_items['cart'] : '<li><span>' . esc_html__('No products in the cart.','buzzblog') . '</span></li>').'</ul>';
	$items =						'<li class="buzzblog-cart menu-item menu-item-has-children has-sub-menu">
												<a href="'.esc_url($woocommerce->cart->get_cart_url()).'" class="cart-link" data-type="title" title="cart">
													<span class="cart-icon-container">';
	$items .= '<i class="'.$woo_icon.'"></i>';
	$items .= 			(( $total_articles !== 0 ) ? '<span class="badge">'.$total_articles.'</span>' : '<span class="badge" style="display: none;"></span>').'
								</span>
							</a>
							'.$cart_container.
							'</li>';

    return $items;
}
?>