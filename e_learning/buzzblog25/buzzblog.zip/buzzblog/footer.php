</div></div>
				</div>
			</div></div><!--#main-->	
<div id="back-top-wrapper" class="visible-desktop">
<p id="back-top">
	        <a href="#top"><span><i class="fa fa-angle-up fa-4"></i></span></a>
</p>
</div>
<?php wp_footer(); ?>
</body>
</html>