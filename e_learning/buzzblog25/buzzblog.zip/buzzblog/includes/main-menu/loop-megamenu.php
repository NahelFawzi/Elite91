<?php
/**
 * Template for displaying posts inside mega menus
 * @package buzzblog
 * @since 1.0.0
 */
global $post;
$thumb = get_post_thumbnail_id();
				$img_url = wp_get_attachment_url( $thumb,'full');
				$img_width = 387;
				$img_height = 257;
				$img = aq_resize( $img_url, $img_width, $img_height, true, true, true );
?>

<article class="post type-<?php echo get_post_type(); ?>">
	<figure class="featured-thumbnail thumbnail large">
				
								<a href="<?php esc_url(the_permalink()); ?>" title="<?php esc_attr(the_title()); ?>"><img src="<?php echo esc_url($img); ?>" width="<?php echo esc_attr($img_width); ?>" height="<?php echo esc_attr($img_height); ?>" alt="<?php esc_attr(the_title());?>" /></a>
							
				</figure>
	<p class="post-title"><?php esc_attr(the_title()); ?></p>
			 <?php if (buzzblog_getVariable('post_date')=='yes') { ?>
	<span class="post-date date"><?php if (buzzblog_getVariable('date_format')) { the_time(buzzblog_getVariable('date_format')); }else{the_time('d M Y');} ?></span>
<?php } ?>
</article>
<!-- /.post -->
