jQuery(function($) {
	// Gallery Management
	var postId   = $('#post_ID').val(),
	    $gallery = $('.buzzblog-pfui-gallery-picker .gallery');

	BUZZBLOGPFUIMediaControl = {

		// Init a new media manager or returns existing frame
		frame: function() {
			if( this._frame )
				return this._frame;

			this._frame = wp.media({
				title: buzzblog_pfui_post_format.media_title,
				library: {
					type: 'image'
				},
				button: {
					text: buzzblog_pfui_post_format.media_button
				},
				multiple: true
			});

			this._frame.on('open', this.updateFrame).state('library').on('select', this.select);

			return this._frame;
		},

		select: function() {
			var selection = this.get('selection');

			selection.each(function(model) {
				var thumbnail = model.attributes.url;
				if( model.attributes.sizes !== undefined && model.attributes.sizes.thumbnail !== undefined )
					thumbnail = model.attributes.sizes.thumbnail.url;
				$gallery.append('<span class="image" data-id="' + model.id + '" title="image"><img src="' + thumbnail + '" alt="" /><span class="close dashicons dashicons-no-alt"></span><a class="dashicons dashicons-edit edit-image image-edit" href="#"></a></span>');
				$gallery.trigger('update');
			});
		},

		updateFrame: function() {
		},

		init: function() {
			$('#wpbody').on('click', '.buzzblog-pfui-gallery-button', function(e){
				e.preventDefault();
				BUZZBLOGPFUIMediaControl.frame().open();
			});
		},
		
		edit: function() {

				var edit_gallery_frame;
				var $image_gallery_ids = $('[name="_format_gallery_images"]');

				$(document).on("click", ".edit-image", function(e) {

					var $el = $(this);
					var attachment_ids = $image_gallery_ids.val();
					e.preventDefault();
					var id_attachment = $el.closest('.image').attr('data-id');

					// Create the media frame.
					edit_gallery_frame = wp.media.frames.downloadable_file = wp.media({
						// Set the title of the modal.
						title: 'Edit images',
						button: {
							text: 'Save changes',
						},
						multiple: false
					});

					edit_gallery_frame.on('open', function(){
						var selection = edit_gallery_frame.state().get('selection');
					    attachment = wp.media.attachment(id_attachment);
					    attachment.fetch();
					    selection.add(attachment);
				    });

					edit_gallery_frame.on('select', function(){

						var selection = edit_gallery_frame.state().get('selection');

						selection.map( function(attachment){

							attachment = attachment.toJSON();
							if ( attachment.id ) {
								if( attachment_ids ){
									var array_ids = attachment_ids.split(',');
									for(var key in array_ids){
										if( array_ids[key] == id_attachment ){
											array_ids[key] = attachment.id;
										}
									}
									attachment_ids = array_ids.join(',');
								}

								
							}
						} );

						$image_gallery_ids.val(attachment_ids);
					});
					edit_gallery_frame.open();
				});
			}
	}
	BUZZBLOGPFUIMediaControl.init();
    BUZZBLOGPFUIMediaControl.edit();

	$gallery.on('update', function(){
		var ids = [];
		$(this).find('> span').each(function(){
			ids.push($(this).data('id'));
		});
		$('[name="_format_gallery_images"]').val(ids.join(','));
	});

	$gallery.sortable({
		placeholder: "buzzblog-pfui-ui-state-highlight",
		revert: 200,
		tolerance: 'pointer',
		stop: function () {
			$gallery.trigger('update');
		}
	});

	$gallery.on('click', 'span.close', function(e){
		$(this).parent().fadeOut(200, function(){
			$(this).remove();
			$gallery.trigger('update');
		});
	});

});
