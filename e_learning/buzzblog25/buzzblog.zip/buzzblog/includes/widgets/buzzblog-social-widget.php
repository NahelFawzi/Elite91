<?php
// =============================== Social Networks Widget ====================================== //
class buzzblog_SocialNetworksWidget extends WP_Widget {

		function buzzblog_SocialNetworksWidget() {

		$widget_ops = array(
			'classname' => 'social_networks_widget', 
			'description' => esc_html__('Link to your social networks.', 'buzzblog') 
		);

		parent::__construct(
			'buzzblog_SocialNetworksWidget',
			esc_html__('Hercules - Social Networks', 'buzzblog'),
			$widget_ops
		);

	}
	function widget( $args, $instance ) {
		extract($args);
		$title = apply_filters('widget_title', $instance['title']);
		
		$networks['Twitter']['link'] = $instance['twitter'];
		$networks['Facebook']['link'] = $instance['facebook'];
		$networks['Flickr']['link'] = $instance['flickr'];
		$networks['Rss']['link'] = $instance['rss'];
		$networks['Linkedin']['link'] = $instance['linkedin'];
		$networks['Instagram']['link'] = $instance['instagram'];
		$networks['Youtube']['link'] = $instance['youtube'];
		$networks['Aim']['link'] = $instance['aim'];
		$networks['Dribbble']['link'] = $instance['dribbble'];
		$networks['Gplus']['link'] = $instance['gplus'];
		$networks['Pinterest']['link'] = $instance['pinterest'];
		$networks['Vimeo']['link'] = $instance['vimeo'];
		$networks['Goodreads']['link'] = $instance['goodreads'];
		$networks['Bloglovin']['link'] = $instance['bloglovin'];
		$networks['Tumblr']['link'] = $instance['tumblr'];
		$networks['Vk']['link'] = $instance['vk'];
		$networks['Mail']['link'] = $instance['mail'];
		$networks['Snapchat']['link'] = $instance['snapchat'];
		
		$networks['Twitter']['label'] = $instance['twitter_label'];
		$networks['Facebook']['label'] = $instance['facebook_label'];
		$networks['Flickr']['label'] = $instance['flickr_label'];
		$networks['Rss']['label'] = $instance['rss_label'];
		$networks['Linkedin']['label'] = $instance['linkedin_label'];
		$networks['Instagram']['label'] = $instance['instagram_label'];
		$networks['Youtube']['label'] = $instance['youtube_label'];
		$networks['Aim']['label'] = $instance['aim_label'];
        $networks['Dribbble']['label'] = $instance['dribbble_label'];
		$networks['Gplus']['label'] = $instance['gplus_label'];
		$networks['Pinterest']['label'] = $instance['pinterest_label'];
		$networks['Vimeo']['label'] = $instance['vimeo_label'];
		$networks['Goodreads']['label'] = $instance['goodreads_label'];
		$networks['Bloglovin']['label'] = $instance['bloglovin_label'];
		$networks['Tumblr']['label'] = $instance['tumblr_label'];
		$networks['Vk']['label'] = $instance['vk_label'];
		$networks['Mail']['label'] = $instance['mail_label'];
		$networks['Snapchat']['label'] = $instance['snapchat_label'];
		
		$display = $instance['display'];
		

		echo wp_kses_post( $args['before_widget'] );
		if ( $title )
    		echo wp_kses_post( $args['before_title'] . $title . $args['after_title'] );
		?>
			
			<!-- BEGIN SOCIAL NETWORKS -->
			<?php if ($display =="labels") {
				$addClass = "social__list_label";
			} elseif ($display == "both") { 
				$addClass = "social__list_both";
			} elseif ($display == "icons") { 
				$addClass = "social__list";
			} ?>
			
			<div class="social <?php echo esc_attr($addClass) ?> unstyled">
				
			<?php foreach(array("Facebook", "Twitter", "Flickr", "Linkedin", "Dribbble", "Pinterest", "Vimeo", "Gplus", "Instagram", "Aim", "Youtube", "Goodreads", "Bloglovin", "Snapchat", "Tumblr", "Vk", "Mail","Rss") as $network) : ?>
	    		<?php if (!empty($networks[$network]['link'])) : ?>
									<?php if ($display == "both") { ?>
						<a target="_blank" class="hs-icon hs hs-<?php echo strtolower($network);?> icon-2x social_link social_link__<?php echo strtolower(esc_attr($network)); ?>" href="<?php echo esc_url($networks[$network]['link']); ?>">
							<span class="social_label"><?php if (($networks[$network]['label'])!=="") { echo $networks[$network]['label']; } else { echo $network; } ?></span>
							</a>
						<?php } ?>
					<?php if ($display == "icons") { ?>
						<a target="_blank" class="hs-icon hs hs-<?php echo strtolower($network);?> icon-2x social_link social_link__<?php echo strtolower(esc_attr($network)); ?>" href="<?php echo esc_url($networks[$network]['link']); ?>">
							</a>
						<?php } ?>
										<?php if ($display == "labels") { ?>
						<a target="_blank" class="social_link social_link__<?php echo strtolower(esc_attr($network)); ?>" href="<?php echo esc_url($networks[$network]['link']); ?>">
							<span class="social_label_only"><?php if (($networks[$network]['label'])!=="") { echo esc_attr($networks[$network]['label']); } else { echo esc_attr($network); } ?></span>
							</a>
						<?php } ?>
				
				<?php endif; ?>
			<?php endforeach; ?>
		      
   		</div>
   		<!-- END SOCIAL NETWORKS -->
      
		<?php
		echo wp_kses_post( $args['after_widget'] );
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		
		$instance['twitter'] = $new_instance['twitter'];
		$instance['facebook'] = $new_instance['facebook'];
		$instance['flickr'] = $new_instance['flickr'];
		$instance['rss'] = $new_instance['rss'];
		$instance['linkedin'] = $new_instance['linkedin'];
		$instance['instagram'] = $new_instance['instagram'];
		$instance['youtube'] = $new_instance['youtube'];
		$instance['aim'] = $new_instance['aim'];
		$instance['dribbble'] = $new_instance['dribbble'];
		$instance['deviantart'] = $new_instance['deviantart'];
		$instance['gplus'] = $new_instance['gplus'];
		$instance['pinterest'] = $new_instance['pinterest'];
		$instance['vimeo'] = $new_instance['vimeo'];
		$instance['goodreads'] = $new_instance['goodreads'];
		$instance['bloglovin'] = $new_instance['bloglovin'];
		$instance['tumblr'] = $new_instance['tumblr'];
		$instance['vk'] = $new_instance['vk'];
		$instance['mail'] = $new_instance['mail'];
		$instance['snapchat'] = $new_instance['snapchat'];
		
		$instance['twitter_label'] = $new_instance['twitter_label'];
		$instance['facebook_label'] = $new_instance['facebook_label'];
		$instance['flickr_label'] = $new_instance['flickr_label'];
		$instance['rss_label'] = $new_instance['rss_label'];
		$instance['linkedin_label'] = $new_instance['linkedin_label'];
		$instance['instagram_label'] = $new_instance['instagram_label'];
		$instance['youtube_label'] = $new_instance['youtube_label'];
		$instance['aim_label'] = $new_instance['aim_label'];
		$instance['dribbble_label'] = $new_instance['dribbble_label'];
		$instance['deviantart_label'] = $new_instance['deviantart_label'];
		$instance['gplus_label'] = $new_instance['gplus_label'];
		$instance['pinterest_label'] = $new_instance['pinterest_label'];
		$instance['vimeo_label'] = $new_instance['vimeo_label'];
		$instance['goodreads_label'] = $new_instance['goodreads_label'];
        $instance['bloglovin_label'] = $new_instance['bloglovin_label'];
		$instance['snapchat_label'] = $new_instance['snapchat_label'];
		$instance['tumblr_label'] = $new_instance['tumblr_label'];
		$instance['vk_label'] = $new_instance['vk_label'];
		$instance['mail_label'] = $new_instance['mail_label'];
		
		$instance['display'] = $new_instance['display'];

		return $instance;
	}

	function form( $instance ) {
		/* Set up some default widget settings. */
		$defaults = array( 'title' => '', 'twitter' => '', 'twitter_label' => '', 'facebook' => '', 'facebook_label' => '', 'flickr' => '', 'flickr_label' => '', 'rss' => '', 'rss_label' => '', 'feed_label' => '', 'linkedin' => '', 'linkedin_label' => '', 'aim' => '', 'aim_label' => '', 'goodreads' => '', 'goodreads_label' => '', 'snapchat' => '', 'snapchat_label' => '', 'bloglovin' => '', 'bloglovin_label' => '', 'tumblr' => '', 'tumblr_label' => '', 'vk' => '', 'vk_label' => '', 'mail' => '', 'mail_label' => '', 'dribbble' => '', 'dribbble_label' => '', 'pinterest' => '', 'pinterest_label' => '', 'vimeo' => '', 'vimeo_label' => '', 'deviantart' => '', 'deviantart_label' => '', 'gplus' => '', 'gplus_label' => '', 'instagram' => '', 'instagram_label' => '', 'youtube' => '', 'youtube_label' => '', 'display' => 'icons', 'text' => '');
		$instance = wp_parse_args( (array) $instance, $defaults );
			
		$twitter = $instance['twitter'];		
		$facebook = $instance['facebook'];
		$flickr = $instance['flickr'];		
		$rss = $instance['rss'];
		$linkedin = $instance['linkedin'];	
		$instagram = $instance['instagram'];
		$youtube = $instance['youtube'];
		$aim = $instance['aim'];
		$dribbble = $instance['dribbble'];
		$deviantart = $instance['deviantart'];
		$gplus = $instance['gplus'];
		$pinterest = $instance['pinterest'];
		$vimeo = $instance['vimeo'];
		$goodreads = $instance['goodreads'];
		$bloglovin = $instance['bloglovin'];
		$snapchat = $instance['snapchat'];
		$tumblr = $instance['tumblr'];
		$vk = $instance['vk'];
		$mail = $instance['mail'];
		
		$twitter_label = $instance['twitter_label'];
		$facebook_label = $instance['facebook_label'];
		$flickr_label = $instance['flickr_label'];
		$rss_label = $instance['rss_label'];
		$linkedin_label = $instance['linkedin_label'];
		$instagram_label = $instance['instagram_label'];
		$youtube_label = $instance['youtube_label'];
		$aim_label = $instance['aim_label'];
		$dribbble_label = $instance['dribbble_label'];
		$deviantart_label = $instance['deviantart_label'];
		$gplus_label = $instance['gplus_label'];
		$pinterest_label = $instance['pinterest_label'];
		$vimeo_label = $instance['vimeo_label'];
	    $goodreads_label = $instance['goodreads_label'];
        $bloglovin_label = $instance['bloglovin_label'];
		$snapchat_label = $instance['snapchat_label'];
		$tumblr_label = $instance['tumblr_label'];
		$vk_label = $instance['vk_label'];
		$mail_label = $instance['mail_label'];
		
		$display = $instance['display'];		
		$title = strip_tags($instance['title']);
		$text = format_to_edit($instance['text']);
?>
		<p><label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>
    
		<fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Facebook', 'buzzblog'); ?>:</legend>
			
			<p><label for="<?php echo esc_attr($this->get_field_id('facebook')); ?>"><?php esc_html_e('Facebook URL:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('facebook')); ?>" name="<?php echo esc_attr($this->get_field_name('facebook')); ?>" type="text" value="<?php echo esc_attr($facebook); ?>" /></p>
			
			<p><label for="<?php echo esc_attr($this->get_field_id('facebook_label')); ?>"><?php esc_html_e('Facebook label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('facebook_label')); ?>" name="<?php echo esc_attr($this->get_field_name('facebook_label')); ?>" type="text" value="<?php echo esc_attr($facebook_label); ?>" /></p>
		</fieldset>	
		
        <fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Twitter', 'buzzblog'); ?>:</legend>	
		<p><label for="<?php echo esc_attr($this->get_field_id('twitter')); ?>"><?php esc_html_e('Twitter URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('twitter')); ?>" name="<?php echo esc_attr($this->get_field_name('twitter')); ?>" type="text" value="<?php echo esc_attr($twitter); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('twitter_label')); ?>"><?php esc_html_e('Twitter label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('twitter_label')); ?>" name="<?php echo esc_attr($this->get_field_name('twitter_label')); ?>" type="text" value="<?php echo esc_attr($twitter_label); ?>" /></p>
        </fieldset>	
		
        <fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Flickr', 'buzzblog'); ?>:</legend>
		<p><label for="<?php echo esc_attr($this->get_field_id('flickr')); ?>"><?php esc_html_e('Flickr URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('flickr')); ?>" name="<?php echo esc_attr($this->get_field_name('flickr')); ?>" type="text" value="<?php echo esc_attr($flickr); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('flickr_label')); ?>"><?php esc_html_e('Flickr label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('flickr_label')); ?>" name="<?php echo esc_attr($this->get_field_name('flickr_label')); ?>" type="text" value="<?php echo esc_attr($flickr_label); ?>" /></p>
        </fieldset>	
		
       
    
    <fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Linkedin', 'buzzblog'); ?>:</legend>
    <p><label for="<?php echo esc_attr($this->get_field_id('linkedin')); ?>"><?php esc_html_e('Linkedin URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('linkedin')); ?>" name="<?php echo esc_attr($this->get_field_name('linkedin')); ?>" type="text" value="<?php echo esc_attr($linkedin); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('linkedin_label')); ?>"><?php esc_html_e('Linkedin label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('linkedin_label')); ?>" name="<?php echo esc_attr($this->get_field_name('linkedin_label')); ?>" type="text" value="<?php echo esc_attr($linkedin_label); ?>" /></p>
        </fieldset>	
    
    <fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Instagram', 'buzzblog'); ?>:</legend>
    <p><label for="<?php echo esc_attr($this->get_field_id('instagram')); ?>"><?php esc_html_e('Instagram URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('instagram')); ?>" name="<?php echo esc_attr($this->get_field_name('instagram')); ?>" type="text" value="<?php echo esc_attr($instagram); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('instagram_label')); ?>"><?php esc_html_e('Instagram label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('instagram_label')); ?>" name="<?php echo esc_attr($this->get_field_name('instagram_label')); ?>" type="text" value="<?php echo esc_attr($instagram_label); ?>" /></p>
        </fieldset>	
    
    <fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Youtube', 'buzzblog'); ?>:</legend>
    <p><label for="<?php echo esc_attr($this->get_field_id('youtube')); ?>"><?php esc_html_e('Youtube URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('youtube')); ?>" name="<?php echo esc_attr($this->get_field_name('youtube')); ?>" type="text" value="<?php echo esc_attr($youtube); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('youtube_label')); ?>"><?php esc_html_e('Youtube label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('youtube_label')); ?>" name="<?php echo esc_attr($this->get_field_name('youtube_label')); ?>" type="text" value="<?php echo esc_attr($youtube_label); ?>" /></p>
        </fieldset>	
		
		<fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Aim', 'buzzblog'); ?>:</legend>
		<p><label for="<?php echo esc_attr($this->get_field_id('aim')); ?>"><?php esc_html_e('Aim URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('aim')); ?>" name="<?php echo esc_attr($this->get_field_name('aim')); ?>" type="text" value="<?php echo esc_attr($aim); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('aim_label')); ?>"><?php esc_html_e('Aim label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('aim_label')); ?>" name="<?php echo esc_attr($this->get_field_name('aim_label')); ?>" type="text" value="<?php echo esc_attr($aim_label); ?>" /></p>
        </fieldset>	
		
		<fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Dribbble', 'buzzblog'); ?>:</legend>
		<p><label for="<?php echo esc_attr($this->get_field_id('dribbble')); ?>"><?php esc_html_e('Dribbble URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('dribbble')); ?>" name="<?php echo esc_attr($this->get_field_name('dribbble')); ?>" type="text" value="<?php echo esc_attr($dribbble); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('dribbble_label')); ?>"><?php esc_html_e('Dribbble label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('dribbble_label')); ?>" name="<?php echo esc_attr($this->get_field_name('dribbble_label')); ?>" type="text" value="<?php echo esc_attr($dribbble_label); ?>" /></p>
        </fieldset>	
		
		<fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Gplus', 'buzzblog'); ?>:</legend>
		<p><label for="<?php echo esc_attr($this->get_field_id('gplus')); ?>"><?php esc_html_e('Gplus URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('gplus')); ?>" name="<?php echo esc_attr($this->get_field_name('gplus')); ?>" type="text" value="<?php echo esc_attr($gplus); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('gplus_label')); ?>"><?php esc_html_e('Gplus label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('gplus_label')); ?>" name="<?php echo esc_attr($this->get_field_name('gplus_label')); ?>" type="text" value="<?php echo esc_attr($gplus_label); ?>" /></p>
        </fieldset>	
		
		<fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Pinterest', 'buzzblog'); ?>:</legend>
		<p><label for="<?php echo esc_attr($this->get_field_id('pinterest')); ?>"><?php esc_html_e('Pinterest URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('pinterest')); ?>" name="<?php echo esc_attr($this->get_field_name('pinterest')); ?>" type="text" value="<?php echo esc_attr($pinterest); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('pinterest_label')); ?>"><?php esc_html_e('Pinterest label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('pinterest_label')); ?>" name="<?php echo esc_attr($this->get_field_name('pinterest_label')); ?>" type="text" value="<?php echo esc_attr($pinterest_label); ?>" /></p>
        </fieldset>
		
		<fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Vimeo', 'buzzblog'); ?>:</legend>
		<p><label for="<?php echo esc_attr($this->get_field_id('vimeo')); ?>"><?php esc_html_e('Vimeo URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('vimeo')); ?>" name="<?php echo esc_attr($this->get_field_name('vimeo')); ?>" type="text" value="<?php echo esc_attr($vimeo); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('vimeo_label')); ?>"><?php esc_html_e('Vimeo label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('vimeo_label')); ?>" name="<?php echo esc_attr($this->get_field_name('vimeo_label')); ?>" type="text" value="<?php echo esc_attr($vimeo_label); ?>" /></p>
        </fieldset>
		
		<fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Bloglovin', 'buzzblog'); ?>:</legend>
		<p><label for="<?php echo esc_attr($this->get_field_id('bloglovin')); ?>"><?php esc_html_e('Bloglovin URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('bloglovin')); ?>" name="<?php echo esc_attr($this->get_field_name('bloglovin')); ?>" type="text" value="<?php echo esc_attr($bloglovin); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('bloglovin_label')); ?>"><?php esc_html_e('Bloglovin label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('bloglovin_label')); ?>" name="<?php echo esc_attr($this->get_field_name('bloglovin_label')); ?>" type="text" value="<?php echo esc_attr($bloglovin_label); ?>" /></p>
        </fieldset>
				<fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Snapchat', 'buzzblog'); ?>:</legend>
		<p><label for="<?php echo esc_attr($this->get_field_id('snapchat')); ?>"><?php esc_html_e('Snapchat URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('snapchat')); ?>" name="<?php echo esc_attr($this->get_field_name('snapchat')); ?>" type="text" value="<?php echo esc_attr($snapchat); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('snapchat_label')); ?>"><?php esc_html_e('Snapchat label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('snapchat_label')); ?>" name="<?php echo esc_attr($this->get_field_name('snapchat_label')); ?>" type="text" value="<?php echo esc_attr($snapchat_label); ?>" /></p>
        </fieldset>
		<fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Tumblr', 'buzzblog'); ?>:</legend>
		<p><label for="<?php echo esc_attr($this->get_field_id('tumblr')); ?>"><?php esc_html_e('Tumblr URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('tumblr')); ?>" name="<?php echo esc_attr($this->get_field_name('tumblr')); ?>" type="text" value="<?php echo esc_attr($tumblr); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('tumblr_label')); ?>"><?php esc_html_e('Tumblr label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('tumblr_label')); ?>" name="<?php echo esc_attr($this->get_field_name('tumblr_label')); ?>" type="text" value="<?php echo esc_attr($tumblr_label); ?>" /></p>
        </fieldset>
		
		<fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Vk', 'buzzblog'); ?>:</legend>
		<p><label for="<?php echo esc_attr($this->get_field_id('vk')); ?>"><?php esc_html_e('Vk URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('vk')); ?>" name="<?php echo esc_attr($this->get_field_name('vk')); ?>" type="text" value="<?php echo esc_attr($vk); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('vk_label')); ?>"><?php esc_html_e('Vk label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('vk_label')); ?>" name="<?php echo esc_attr($this->get_field_name('vk_label')); ?>" type="text" value="<?php echo esc_attr($vk_label); ?>" /></p>
        </fieldset>
		
		<fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('Goodreads', 'buzzblog'); ?>:</legend>
		<p><label for="<?php echo esc_attr($this->get_field_id('goodreads')); ?>"><?php esc_html_e('Goodreads URL:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('goodreads')); ?>" name="<?php echo esc_attr($this->get_field_name('goodreads')); ?>" type="text" value="<?php echo esc_attr($goodreads); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('goodreads_label')); ?>"><?php esc_html_e('Goodreads label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('goodreads_label')); ?>" name="<?php echo esc_attr($this->get_field_name('goodreads_label')); ?>" type="text" value="<?php echo esc_attr($goodreads_label); ?>" /></p>
        </fieldset>
		
				 <fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('E-mail', 'buzzblog'); ?>:</legend>
		<p><label for="<?php echo esc_attr($this->get_field_id('mail')); ?>"><?php esc_html_e('E-mail:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('mail')); ?>" name="<?php echo esc_attr($this->get_field_name('mail')); ?>" type="text" value="<?php echo esc_attr($mail); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('mail_label')); ?>"><?php esc_html_e('E-mail label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('mail_label')); ?>" name="<?php echo esc_attr($this->get_field_name('mail_label')); ?>" type="text" value="<?php echo esc_attr($mail_label); ?>" /></p>
        </fieldset>	

		 <fieldset style="border:1px solid #dfdfdf; padding:10px 10px 0; margin-bottom:1em;">
			<legend style="padding:0 5px;"><?php esc_html_e('RSS feed', 'buzzblog'); ?>:</legend>
		<p><label for="<?php echo esc_attr($this->get_field_id('rss')); ?>"><?php esc_html_e('RSS feed:', 'buzzblog'); ?></label>
		<input class="widefat" id="<?php echo esc_attr($this->get_field_id('rss')); ?>" name="<?php echo esc_attr($this->get_field_name('rss')); ?>" type="text" value="<?php echo esc_attr($rss); ?>" /></p>
        <p><label for="<?php echo esc_attr($this->get_field_id('rss_label')); ?>"><?php esc_html_e('RSS label:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('rss_label')); ?>" name="<?php echo esc_attr($this->get_field_name('rss_label')); ?>" type="text" value="<?php echo esc_attr($rss_label); ?>" /></p>
        </fieldset>	

		<p><?php esc_html_e('Display:', 'buzzblog'); ?></p>
		<label for="<?php echo esc_attr($this->get_field_id('icons')); ?>"><input type="radio" name="<?php echo esc_attr($this->get_field_name('display')); ?>" value="icons" id="<?php echo esc_attr($this->get_field_id('icons')); ?>" <?php checked($display, "icons"); ?>></input><?php esc_html_e('Icons', 'buzzblog'); ?></label>
		<label for="<?php echo esc_attr($this->get_field_id('labels')); ?>"><input type="radio" name="<?php echo esc_attr($this->get_field_name('display')); ?>" value="labels" id="<?php echo esc_attr($this->get_field_id('labels')); ?>" <?php checked($display, "labels"); ?>></input><?php esc_html_e('Labels', 'buzzblog'); ?></label>
        <label for="<?php echo esc_attr($this->get_field_id('both')); ?>"><input type="radio" name="<?php echo esc_attr($this->get_field_name('display')); ?>" value="both" id="<?php echo esc_attr($this->get_field_id('both')); ?>" <?php checked($display, "both"); ?>></input><?php esc_html_e('Both', 'buzzblog'); ?></label>
    
<?php
	}
}
add_action( 'widgets_init', 'buzzblog_SocialNetworksWidget' );

function buzzblog_SocialNetworksWidget() {
	register_widget( 'buzzblog_SocialNetworksWidget' );
}
?>