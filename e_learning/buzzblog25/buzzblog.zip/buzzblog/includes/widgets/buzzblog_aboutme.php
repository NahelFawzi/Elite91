<?php
/*
About me box
*/
class buzzblog_aboutmebox extends WP_widget {

	function buzzblog_aboutmebox() {

		$widget_ops = array(
			'classname' => 'buzzblog_aboutmebox', 
			'description' => esc_html__('A widget that displays the about me box', 'buzzblog') 
		);

		parent::__construct(
			'buzzblog_aboutmebox',
			esc_html__('Hercules - About me box', 'buzzblog'),
			$widget_ops
		);

	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'aboutme_headline' => '', 'text' => '', 'image_author_uri' => false, 'global_link' => '', 'circle_img' => '', 'signature_img' => '', 'global_link_text' => '', 'global_link_href' => '') );
		
		$title 				= strip_tags($instance['title']);
		$aboutme_headline 	= strip_tags( $instance['aboutme_headline']);
		$text 				= $instance['text'];
		$image_author_uri 	= $instance['image_author_uri'];
		$global_link = $instance['global_link'];
		$circle_img = $instance['circle_img'];
		$signature_img = $instance['signature_img'];
		$global_link_text = $instance['global_link_text']; 
		$global_link_href = $instance['global_link_href'];
	?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'buzzblog'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
		</p>
	    <p>
      		<label for="<?php echo esc_attr($this->get_field_id('image_author_uri')); ?>"><?php esc_html_e('Author image', 'buzzblog'); ?>:</label><br />
			<input type="hidden" name="<?php echo esc_attr($this->get_field_name('image_author_uri')); ?>" id="<?php echo esc_attr($this->get_field_id('image_author_uri')); ?>" value="<?php echo esc_url($image_author_uri); ?>" />
			<input class="button" onClick="hs_open_uploader(this, 'about_me_image')" id="about_image_upload" value="Upload" />
	    </p>
      	<p class="about_me_image">
      		<img src="<?php echo esc_url($image_author_uri); ?>" style="width:100%;">
      	</p>
  <p>
            <label for="<?php echo esc_attr($this->get_field_id("circle_img")); ?>">
          <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id("circle_img")); ?>" name="<?php echo esc_attr($this->get_field_name("circle_img")); ?>"<?php checked( (bool) $instance["circle_img"], true ); ?> />
          <?php esc_html_e( 'Do you want the picture to be in the circle? Your image should be a perfect square.', 'buzzblog' ); ?>
      </label>
     
  </p>
  <p>
            <label for="<?php echo esc_attr($this->get_field_id("signature_img")); ?>">
          <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id("circle_img")); ?>" name="<?php echo esc_attr($this->get_field_name("signature_img")); ?>"<?php checked( (bool) $instance["signature_img"], true ); ?> />
          <?php esc_html_e( 'Do you want to display custom signature ?', 'buzzblog' ); ?>
      </label>
     
  </p>
	    <p>
      		<label for="<?php echo esc_attr($this->get_field_id('aboutme_headline')); ?>"><?php esc_html_e('Headline', 'buzzblog'); ?>:</label><br />
			<input class="widefat" type="text" id="<?php echo esc_attr($this->get_field_id('aboutme_headline')); ?>" name="<?php echo esc_attr($this->get_field_name('aboutme_headline')); ?>" value="<?php echo esc_attr($aboutme_headline); ?>">
	    </p>
	    <p>
      		<label for="<?php echo esc_attr($this->get_field_id('text')); ?>"><?php esc_html_e('Info', 'buzzblog'); ?>:</label><br />
			<textarea class="widefat" rows="5" id="<?php echo esc_attr($this->get_field_id('text')); ?>" name="<?php echo esc_attr($this->get_field_name('text')); ?>"><?php echo esc_textarea($text); ?></textarea>
	    </p>
  <fieldset style="border:1px solid #F1F1F1; padding:10px 10px 0; margin-bottom:1em;">
  <legend style="padding:0 5px;"><?php esc_html_e('Link to about me page', 'buzzblog'); ?>:</legend>
  <p>
      <label for="<?php echo esc_attr($this->get_field_id("global_link")); ?>">
          <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id("global_link")); ?>" name="<?php echo esc_attr($this->get_field_name("global_link")); ?>"<?php checked( (bool) $instance["global_link"], true ); ?> />
          <?php esc_html_e( 'Show link to about me page', 'buzzblog' ); ?>
      </label>
  </p>
  
  <p>
  <label for="<?php echo esc_attr($this->get_field_id("global_link_text")); ?>">
    <?php esc_html_e( 'Link text', 'buzzblog' ); ?>:
    <input class="widefat" id="<?php echo esc_attr($this->get_field_id("global_link_text")); ?>" name="<?php echo esc_attr($this->get_field_name("global_link_text")); ?>" type="text" value="<?php echo esc_attr($instance["global_link_text"]); ?>" /> <span style="font-size:11px; color:#999;"><?php esc_html_e( '(default: "Read More")', 'buzzblog' ); ?></span>
  </label>
  </p>
  <p>
      <label for="<?php echo esc_attr($this->get_field_id("global_link_href")); ?>">
          <?php esc_html_e( 'Link URL', 'buzzblog' ); ?>:
          <input class="widefat" id="<?php echo esc_attr($this->get_field_id("global_link_href")); ?>" name="<?php echo esc_attr($this->get_field_name("global_link_href")); ?>" type="text" value="<?php echo esc_url($instance["global_link_href"]); ?>" />
      </label>
  </p>
  </fieldset>
	<?php
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] 			= strip_tags($new_instance['title']);
		$instance['aboutme_headline'] 			= strip_tags($new_instance['aboutme_headline']);
		$instance['image_author_uri'] 		= $new_instance['image_author_uri'];
		$instance['global_link'] = strip_tags($new_instance['global_link']);
		$instance['circle_img'] = strip_tags($new_instance['circle_img']);
		$instance['signature_img'] = strip_tags($new_instance['signature_img']);
  $instance['global_link_href'] = strip_tags($new_instance['global_link_href']);
  $instance['global_link_text'] = strip_tags($new_instance['global_link_text']);

		if ( current_user_can('unfiltered_html') )
			$instance['text'] =  $new_instance['text'];
		else
			$instance['text'] = stripslashes( wp_filter_post_kses( addslashes($new_instance['text']) ) );
		$instance['filter'] = isset($new_instance['filter']);
		return $instance;
	}

	function widget( $args, $instance ) {
		extract($args);
		$title 	= apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
		$text 	= apply_filters( 'widget_text', empty( $instance['text'] ) ? '' : $instance['text'], $instance );
		$aboutme_headline 	= apply_filters( 'widget_text', empty( $instance['aboutme_headline'] ) ? '' : $instance['aboutme_headline'], $instance );


		echo wp_kses_post( $args['before_widget'] );
		if ( $title ) {
			echo wp_kses_post( $args['before_title'] . $title . $args['after_title'] );
		} 

			echo '<div class="widget-body">';

				if(!empty($instance['image_author_uri'])){
				list($width, $height, $type, $attr) = getimagesize(esc_url($instance['image_author_uri']));
				if (isset($instance['circle_img']) && !empty($instance['circle_img'])) {$imgcircle = 'class="img-circle"';}else{$imgcircle = '';}
					echo '<div class="hs_about_img"><figure class="featured-thumbnail thumbnail large">
        <a class="image-wrap image-popup-no-margins"  href="'.esc_url($instance['image_author_uri']).'" data-rel="Photo">
            <img src="'.esc_url($instance['image_author_uri']).'" '.$imgcircle.' '.$attr.' alt="'.$aboutme_headline.'" />
        </a>
    </figure></div>';
				}  
				echo '<div class="hs_aboutme_text post-list-inner">';
				echo !empty( $aboutme_headline ) ? '<h3>'.$aboutme_headline.'</h3><span></span>' : '';
				if(buzzblog_getVariable('custom-signature-image','url') !='' &&  isset($instance['signature_img']) && !empty($instance['signature_img'])) {
$buzzblog_my_custom_signature_image = '<div class="signature-image"><img src="'.esc_url( buzzblog_getVariable('custom-signature-image','url')).'" width="'.esc_attr( buzzblog_getVariable('custom-signature-image','width')).'" height="'.esc_attr( buzzblog_getVariable('custom-signature-image','height')).'" alt="signature" title="signature" /></div>';
}else{$buzzblog_my_custom_signature_image ='';}
				echo '<p class="about_para">'.(!empty( $instance['filter'] ) ? wpautop( $text ) : $text).'</p>'.$buzzblog_my_custom_signature_image;
				if (isset($instance['global_link']) && !empty($instance['global_link'])) {
	  echo '<div class="readmore-button"><a href="'.$instance['global_link_href'].'" class="btn btn-default btn-normal">';
	  if($instance['global_link_text']==""){
	  esc_html_e( 'Read more', 'buzzblog' );
	  }else{
	  echo esc_attr($instance['global_link_text']);
	  } 
	  echo '</a></div>';
	 }
				echo '</div>';
			echo '</div>';

		echo wp_kses_post( $args['after_widget'] );
	}
}

if(!function_exists('buzzblog_aboutme_enq')){
	function buzzblog_aboutme_enq()
	{
	  wp_enqueue_media();
	  wp_enqueue_script('buzzblog-hsenq', trailingslashit(get_template_directory_uri()) . 'admin-panel/js/admin-script.js', array('jquery'), null, true);
	}
	add_action('admin_enqueue_scripts', 'buzzblog_aboutme_enq');
}

add_action( 'widgets_init', 'buzzblog_aboutmebox' );

function buzzblog_aboutmebox() {
	register_widget( 'buzzblog_aboutmebox' );
}