<?php
/*
// =============================== My Recent News ======================================*/
class buzzblog_RecentNewsWidget extends WP_Widget {

	function buzzblog_RecentNewsWidget() {

		$widget_ops = array(
			'classname' => 'buzzblog_RecentNewsWidget', 
			'description' => esc_html__('A widget that displays posts', 'buzzblog') 
		);
        $control_ops = array('width' => 500, 'height' => 350);
		parent::__construct(
			'buzzblog_RecentNewsWidget',
			esc_html__('Hercules - Recent News', 'buzzblog'),
			$widget_ops, $control_ops
		);

	}
/**
 * Displays custom posts widget on blog.
 */
function widget($args, $instance) {
	global $post;
	$post_old = $post; // Save the post object.
	
	extract( $args );
	$title 	= apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
  if (isset($instance['excerpt_length']))
    $limit = apply_filters('widget_title', $instance['excerpt_length']);
  else
    $limit = 0;

	
  $valid_sort_orders = array('date', 'title', 'rand');
  if ( in_array($instance['sort_by'], $valid_sort_orders) ) {
    $sort_by = $instance['sort_by'];
    $sort_order = (bool) $instance['asc_sort_order'] ? 'ASC' : 'DESC';
  } else {
    // by default, display latest first
    $sort_by = 'date';
    $sort_order = 'DESC';
  }
	
	// Get array of post info.
	
	$arg = array(
		'showposts' => $instance["num"],
		'category_name' => $instance['posts_category'],
		'post_type' => 'post',
		'orderby' => $sort_by,
		'order' => $sort_order,
		'tax_query' => array(
		 'relation' => 'AND',
			array(
				'taxonomy' => 'post_format',
				
				'terms' => array('post-format-aside', 'post-format-gallery', 'post-format-link', 'post-format-image', 'post-format-quote', 'post-format-audio', 'post-format-video'),
				'operator' => 'NOT IN'
			)
		)
	);
	
  $cat_posts = new WP_Query($arg);
	
	echo wp_kses_post( $args['before_widget'] );
	
		 if ( $title ) {
			echo wp_kses_post( $args['before_title'] . $title . $args['after_title'] );
		} 

	// Posts list
    if($instance['container_class']==""){
	echo "<ul class='post-list unstyled'>\n";
	}else{
    echo "<ul class='post-list unstyled " .$instance['container_class'] ."'>\n";
    }
	
	$limittext = $limit;
	$posts_counter = 0;
	while ( $cat_posts->have_posts() )
	{
		$cat_posts->the_post(); $posts_counter++;
	?>
    <?php if ($instance['posttype'] == "testi") {
      $custom = get_post_custom($post->ID);
      $testiname = $custom["testimonial-name"][0];
      $testiurl = $custom["testimonial-url"][0];
    }

    ?>
		<li class="cat_post_item-<?php echo esc_attr($posts_counter); ?> clearfix">

					
         <div class="post-list_h">
		 		         <?php if ( $instance['show_title'] ) : ?>
			  <h4><a class="post-title" href="<?php esc_url(the_permalink()); ?>" rel="bookmark" title="<?php esc_attr(the_title_attribute()); ?>"><?php if ( $instance['show_title_date'] ) {?><?php the_time('m-d-Y'); ?><?php }else{?><?php esc_attr(the_title()); ?><?php }?></a></h4>
			<?php endif; ?>
			
					   <div class="small">
   <?php if ( $instance['date'] ) : 
        if (buzzblog_getVariable('post_date')=='yes' or buzzblog_getVariable('post_date')=='') {buzzblog_entry_date();}
       endif; ?>
	  <span class="post_categories">
							<?php 
$post_categories = get_the_category( $post->ID );
echo '| <a class="" href="' . get_category_link( $post_categories[0]->term_id ) . '">'. $post_categories[0]->name .'</a>';
?></span>
      <?php if ( $instance['comment_num'] ) : ?>
        | <span class="post-list_comment"><?php comments_number(); ?></span>
      <?php endif; ?>
      </div>
      		<?php 
        if(has_post_thumbnail()) {
          if ($instance["thumb"]) : ?>
          
		  <figure class="featured-thumbnail thumbnail large">
          <?php if ( $instance['thumb_as_link'] ) : ?>
              <a class="image-wrap" href="<?php esc_url(the_permalink()) ?>">
            <?php endif; ?>

              <?php the_post_thumbnail('thumbnail'); ?>

            <?php if ( $instance['thumb_as_link'] ) : ?>
              </a>
            <?php endif; ?>
			</figure>
          
        <?php endif;
      }		
   ?> 	
   <div class="post-list-inner">
 
        <?php if ( $instance['excerpt'] ) : ?>
		<div class="para">
	       <?php if($limittext=="" || $limittext==0){ ?>
		  <?php if ( $instance['excerpt_as_link'] ) : ?>
                <a href="<?php esc_url(the_permalink()) ?>">
              <?php endif; ?>
           <?php $excerpt = get_the_content();
echo buzzblog_limit_text($excerpt,$limittext); ?>
		  <?php if ( $instance['excerpt_as_link'] ) : ?>
                </a>
              <?php endif; ?>
          <?php }else{ ?>
		  <?php if ( $instance['excerpt_as_link'] ) : ?>
                <a href="<?php esc_url(the_permalink()) ?>">
              <?php endif; ?>
            <?php $excerpt = get_the_content();
echo buzzblog_limit_text($excerpt,$limittext); ?>
		  <?php if ( $instance['excerpt_as_link'] ) : ?>
                </a>
              <?php endif; ?>
          <?php } ?>
		   </div>
        <?php endif; ?>
     
	  
      <?php if ( $instance['more_link'] ) : ?>
        <a href="<?php esc_url(the_permalink()) ?>" class="<?php if($instance['more_link_class']!="") {echo esc_attr($instance['more_link_class']);}else{ ?><?php } ?>"><?php if($instance['more_link_text']==""){  esc_html_e('Read more', 'buzzblog'); }else{ ?><?php echo esc_attr($instance['more_link_text']); ?><?php } ?></a>
      <?php endif; ?>
		</div></div></li><!--//.post-list_li -->
   
	<?php } ?>
	<?php echo "</ul>\n"; ?>
	<?php if ( $instance['global_link'] ) : ?>
	  <a href="<?php echo esc_url($instance['global_link_href']); ?>" class="btn btn-default btn-normal"><?php if($instance['global_link_text']==""){ esc_html_e('View all', 'buzzblog'); }else{ ?><?php echo esc_attr($instance['global_link_text']); ?><?php } ?></a> 
	<?php endif; ?>
	
<?php 	
	echo wp_kses_post( $args['after_widget'] );
	
	$post = $post_old; // Restore the post object.
}

/**
 * Form processing.
 */
function update($new_instance, $old_instance) {
  $instance = $old_instance;
  $instance['asc_sort_order'] = strip_tags($new_instance['asc_sort_order']);
  $instance['thumb'] = strip_tags($new_instance['thumb']);
  $instance['thumb_as_link'] = strip_tags($new_instance['thumb_as_link']);
  $instance['excerpt_length'] = strip_tags($new_instance['excerpt_length']);
  $instance['sort_by'] = strip_tags($new_instance['sort_by']);
  $instance['num'] = strip_tags($new_instance['num']);
  $instance['posttype'] = strip_tags($new_instance['posttype']);
  $instance['title'] = strip_tags($new_instance['title']);
  $instance['container_class'] = strip_tags($new_instance['container_class']);
  $instance['posts_category'] = strip_tags($new_instance['posts_category']);
  $instance['date'] = strip_tags($new_instance['date']);
  $instance['comment_num'] = strip_tags($new_instance['comment_num']);
  $instance['show_title'] = strip_tags($new_instance['show_title']);
  $instance['show_title_date'] = strip_tags($new_instance['show_title_date']);
  $instance['excerpt'] = strip_tags($new_instance['excerpt']);
  $instance['excerpt_as_link'] = strip_tags($new_instance['excerpt_as_link']);
  $instance['more_link'] = strip_tags($new_instance['more_link']);
  $instance['more_link_class'] = strip_tags($new_instance['more_link_class']);
  $instance['more_link_text'] = strip_tags($new_instance['more_link_text']);
  $instance['global_link'] = strip_tags($new_instance['global_link']);
  $instance['global_link_href'] = strip_tags($new_instance['global_link_href']);
  $instance['global_link_text'] = strip_tags($new_instance['global_link_text']);
	return $instance;
}

/**
 * The configuration form.
 */
function form($instance) {
  /* Set up some default widget settings. */
  $defaults = array( 'title' => '', 'posttype' => '', 'num' => '', 'sort_by' => '', 'asc_sort_order' => '', 'comment_num' => '', 'date' => '', 'container_class' => '', 'posts_category' => '', 'show_title' => '', 'show_title_date' => '', 'excerpt' => '', 'excerpt_length' => '', 'excerpt_as_link' => '', 'more_link' => '', 'more_link_text' => '', 'more_link_class' => '', 'thumb' => '', 'thumb_as_link' => '', 'global_link' => '', 'global_link_text' => '', 'global_link_href' => '' );
  $instance = wp_parse_args( (array) $instance, $defaults );

  $sort_by = esc_attr($instance['sort_by']);
?>

  <p>
    <label for="<?php echo esc_attr($this->get_field_id("title")); ?>">
        <?php esc_html_e( 'Title', 'buzzblog' ); ?>:
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id("title")); ?>" name="<?php echo esc_attr($this->get_field_name("title")); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />
    </label>
  </p>
  <div style="width:230px; float:left; padding-right:20px; border-right:1px solid #c7c7c7;">

  <p>
      <label for="<?php echo esc_attr($this->get_field_id("num")); ?>">
          <?php esc_html_e('Number of posts to show', 'buzzblog'); ?>:
          <input style="text-align: center;" id="<?php echo esc_attr($this->get_field_id("num")); ?>" name="<?php echo esc_attr($this->get_field_name("num")); ?>" type="text" value="<?php echo absint($instance["num"]); ?>" size='4' />
      </label>
</p>

<p>
  <label for="<?php echo esc_attr($this->get_field_id("sort_by")); ?>">
  <?php esc_html_e('Sort by', 'buzzblog'); ?>:
    <select id="<?php echo esc_attr($this->get_field_id("sort_by")); ?>" name="<?php echo esc_attr($this->get_field_name("sort_by")); ?>">
      <?php
        $options = array('date', 'title', 'rand');
            foreach ($options as $option) {
              echo '<option value="' . $option . '" id="' . $option . '"', $sort_by == $option ? ' selected="selected"' : '', '>', $option, '</option>';
            } ?>
    </select>
  </label>
</p>
  
<p>
  <label for="<?php echo esc_attr($this->get_field_id("asc_sort_order")); ?>">
    <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id("asc_sort_order")); ?>" name="<?php echo esc_attr($this->get_field_name("asc_sort_order")); ?>" value="1" <?php checked( (bool) $instance["asc_sort_order"], true ); ?> />
          <?php esc_html_e( 'Reverse sort order (ascending)', 'buzzblog' ); ?>
  </label>
</p>
<p>
  <label for="<?php echo esc_attr($this->get_field_id("comment_num")); ?>">
      <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id("comment_num")); ?>" name="<?php echo esc_attr($this->get_field_name("comment_num")); ?>"<?php checked( (bool) $instance["comment_num"], true ); ?> />
      <?php esc_html_e( 'Show number of comments', 'buzzblog' ); ?>
  </label>
</p>

<p>
  <label for="<?php echo esc_attr($this->get_field_id("date")); ?>">
      <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id("date")); ?>" name="<?php echo esc_attr($this->get_field_name("date")); ?>"<?php checked( (bool) $instance["date"], true ); ?> />
      <?php esc_html_e( 'Show meta', 'buzzblog' ); ?>
  </label>
</p>

<p>
  <label for="<?php echo esc_attr($this->get_field_id("posts_category")); ?>">
    <?php esc_html_e( 'Category', 'buzzblog' ); ?>:
    <input class="widefat" id="<?php echo esc_attr($this->get_field_id("posts_category")); ?>" name="<?php echo esc_attr($this->get_field_name("posts_category")); ?>" type="text" value="<?php echo esc_attr($instance["posts_category"]); ?>" /> <span style="font-size:11px; color:#999;"><?php esc_html_e( '(category: enter category slug (NOT name))', 'buzzblog' ); ?></span>
  </label>
</p>


<p>
  <label for="<?php echo esc_attr($this->get_field_id("container_class")); ?>">
    <?php esc_html_e( 'Container class', 'buzzblog' ); ?>:
    <input class="widefat" id="<?php echo esc_attr($this->get_field_id("container_class")); ?>" name="<?php echo esc_attr($this->get_field_name("container_class")); ?>" type="text" value="<?php echo esc_attr($instance["container_class"]); ?>" /> <span style="font-size:11px; color:#999;"><?php esc_html_e( '(default: "featured_custom_posts")', 'buzzblog' ); ?></span>
  </label>
</p>

  <fieldset style="border:1px solid #F1F1F1; padding:10px 10px 0; margin-bottom:1em;">
  <legend style="padding:0 5px;"><?php esc_html_e('Post title', 'buzzblog'); ?>:</legend>
  <p>
      <label for="<?php echo esc_attr($this->get_field_id("show_title")); ?>">
          <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id("show_title")); ?>" name="<?php echo esc_attr($this->get_field_name("show_title")); ?>"<?php checked( (bool) $instance["show_title"], true ); ?> />
          <?php esc_html_e( 'Show post title', 'buzzblog' ); ?>
      </label>
  </p>
  <p>
      <label for="<?php echo esc_attr($this->get_field_id("show_title_date")); ?>">
          <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id("show_title_date")); ?>" name="<?php echo esc_attr($this->get_field_name("show_title_date")); ?>"<?php checked( (bool) $instance["show_title_date"], true ); ?> />
          <?php esc_html_e( 'Date as title ("[mm-dd-yyyy]")', 'buzzblog' ); ?>
      </label>
  </p>
  
  </fieldset>

  <fieldset style="border:1px solid #F1F1F1; padding:10px 10px 0; margin-bottom:1em;">
  <legend style="padding:0 5px;"><?php esc_html_e('Excerpt', 'buzzblog'); ?>:</legend>
  <p>
      <label for="<?php echo esc_attr($this->get_field_id("excerpt")); ?>">
          <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id("excerpt")); ?>" name="<?php echo esc_attr($this->get_field_name("excerpt")); ?>"<?php checked( (bool) $instance["excerpt"], true ); ?> />
          <?php esc_html_e( 'Show post excerpt', 'buzzblog' ); ?>
      </label>
  </p>
  <p>
      <label for="<?php echo esc_attr($this->get_field_id("excerpt_length")); ?>">
          <?php esc_html_e( 'Excerpt length (words):', 'buzzblog' ); ?>
      </label>
      <input style="text-align: center;" type="text" id="<?php echo esc_attr($this->get_field_id("excerpt_length")); ?>" name="<?php echo esc_attr($this->get_field_name("excerpt_length")); ?>" value="<?php echo esc_attr($instance["excerpt_length"]); ?>" size="3" />
  </p>
  <p>
      <label for="<?php echo esc_attr($this->get_field_id("excerpt_as_link")); ?>">
          <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id("excerpt_as_link")); ?>" name="<?php echo esc_attr($this->get_field_name("excerpt_as_link")); ?>"<?php checked( (bool) $instance["excerpt_as_link"], true ); ?> />
          <?php esc_html_e( 'Excerpt as link', 'buzzblog' ); ?>
      </label>
  </p>
  </fieldset>
</div>
<div style="width:230px; float:left; padding-left:17px;">
  <fieldset style="border:1px solid #F1F1F1; padding:10px 10px 0; margin-bottom:1em;">
  <legend style="padding:0 5px;"><?php esc_html_e('More link', 'buzzblog'); ?>:</legend>
  <p>
      <label for="<?php echo esc_attr($this->get_field_id("more_link")); ?>">
          <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id("more_link")); ?>" name="<?php echo esc_attr($this->get_field_name("more_link")); ?>"<?php checked( (bool) $instance["more_link"], true ); ?> />
          <?php esc_html_e( 'Show "More link"', 'buzzblog' ); ?>
      </label>
  </p>
  
  <p>
  <label for="<?php echo esc_attr($this->get_field_id("more_link_text")); ?>">
    <?php esc_html_e( 'Link text', 'buzzblog' ); ?>:
    <input class="widefat" id="<?php echo esc_attr($this->get_field_id("more_link_text")); ?>" name="<?php echo esc_attr($this->get_field_name("more_link_text")); ?>" type="text" value="<?php echo esc_attr($instance["more_link_text"]); ?>" /> <span style="font-size:11px; color:#999;"><?php esc_html_e( '(default: "Read more")', 'buzzblog' ); ?></span>
  </label>
  </p>
  <p>
  <label for="<?php echo esc_attr($this->get_field_id("more_link_class")); ?>">
    <?php esc_html_e( 'Link class', 'buzzblog' ); ?>:
    <input class="widefat" id="<?php echo esc_attr($this->get_field_id("more_link_class")); ?>" name="<?php echo esc_attr($this->get_field_name("more_link_class")); ?>" type="text" value="<?php echo esc_attr($instance["more_link_class"]); ?>" /> <span style="font-size:11px; color:#999;"><?php esc_html_e( '(default: "link")', 'buzzblog' ); ?></span>
  </label>
  </p>
  </fieldset>
  <fieldset style="border:1px solid #F1F1F1; padding:10px 10px 0; margin-bottom:1em;">
  <legend style="padding:0 5px;"><?php esc_html_e('Thumbnail', 'buzzblog'); ?>:</legend>
  <?php if ( function_exists('the_post_thumbnail') && current_theme_supports("post-thumbnails") ) : ?>
  <p>
      <label for="<?php echo esc_attr($this->get_field_id("thumb")); ?>">
          <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id("thumb")); ?>" name="<?php echo esc_attr($this->get_field_name("thumb")); ?>" value="1" <?php checked( (bool) $instance["thumb"], true ); ?> />
          <?php esc_html_e( 'Show post thumbnail', 'buzzblog' ); ?>
      </label>
  </p>
  <p>
      <label for="<?php echo esc_attr($this->get_field_id("thumb_as_link")); ?>">
          <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id("thumb_as_link")); ?>" name="<?php echo esc_attr($this->get_field_name("thumb_as_link")); ?>"<?php checked( (bool) $instance["thumb_as_link"], true ); ?> />
          <?php esc_html_e( 'Thumbnail as link', 'buzzblog' ); ?>
      </label>
  </p>
  </fieldset>
  <fieldset style="border:1px solid #F1F1F1; padding:10px 10px 0; margin-bottom:1em;">
  <legend style="padding:0 5px;"><?php esc_html_e('Link to all posts', 'buzzblog'); ?>:</legend>
  <p>
      <label for="<?php echo esc_attr($this->get_field_id("global_link")); ?>">
          <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id("global_link")); ?>" name="<?php echo esc_attr($this->get_field_name("global_link")); ?>"<?php checked( (bool) $instance["global_link"], true ); ?> />
          <?php esc_html_e( 'Show global link to all posts', 'buzzblog' ); ?>
      </label>
  </p>
  <p>
  <label for="<?php echo esc_attr($this->get_field_id("global_link_text")); ?>">
    <?php esc_html_e( 'Link text', 'buzzblog' ); ?>:
    <input class="widefat" id="<?php echo esc_attr($this->get_field_id("global_link_text")); ?>" name="<?php echo esc_attr($this->get_field_name("global_link_text")); ?>" type="text" value="<?php echo esc_attr($instance["global_link_text"]); ?>" /> <span style="font-size:11px; color:#999;"><?php esc_html_e( '(default: "View all")', 'buzzblog' ); ?></span>
  </label>
  </p>
  <p>
      <label for="<?php echo esc_attr($this->get_field_id("global_link_href")); ?>">
          <?php esc_html_e( 'Link URL', 'buzzblog' ); ?>:
          <input class="widefat" id="<?php echo esc_attr($this->get_field_id("global_link_href")); ?>" name="<?php echo esc_attr($this->get_field_name("global_link_href")); ?>" type="text" value="<?php echo esc_attr($instance["global_link_href"]); ?>" />
      </label>
  </p>
  </fieldset>
</div>
<div style="clear:both;"></div>
		<?php endif; ?>
<?php
}
}
add_action( 'widgets_init', 'buzzblog_RecentNewsWidget' );

function buzzblog_RecentNewsWidget() {
	register_widget( 'buzzblog_RecentNewsWidget' );
}
?>