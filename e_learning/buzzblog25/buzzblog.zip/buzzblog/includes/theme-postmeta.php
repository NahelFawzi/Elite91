<?php
add_action('admin_menu', 'buzzblog_add_box');

/*-----------------------------------------------------------------------------------*/
/*	Add metabox to edit page
/*-----------------------------------------------------------------------------------*/
 
function buzzblog_add_box() {
	global $buzzblog_meta_box_all, $buzzblog_meta_box_standard, $buzzblog_meta_box_audio, $buzzblog_meta_box_video, $buzzblog_meta_box_link, $buzzblog_meta_box_gallery;

$buzzblog_meta_box_all = array(
	'id' => 'buzzblog-meta-box-all',
	'title' =>  esc_html__('Sidebar Option', 'buzzblog'),
	'page' => 'post',
	'context' => 'normal',
	'priority' => 'high',
	'fields' => array(
		array( "name" => esc_html__('Sidebar Option','buzzblog'),
				"desc" => esc_html__('Choose Sidebar Option.','buzzblog'),
				"id" => "buzzblog_sidebar_option",
				"type" => "radio",
				"std" => "2cr", 
				"options" => array("2cr", "2cl", "1col")
			)
	),
);
	
$buzzblog_meta_box_standard = array(
	'id' => 'buzzblog-meta-box-standard',
	'title' =>  esc_html__('Layout Settings', 'buzzblog'),
	'page' => 'post',
	'context' => 'normal',
	'priority' => 'high',
	'fields' => array(
		array( "name" => esc_html__('Post layout','buzzblog'),
				"desc" => esc_html__('Choose post layout.','buzzblog'),
				"id" => "buzzblog_standard_layout_format",
				"type" => "select",
				"std" => esc_html__('normal', 'buzzblog'), 
				"options" => array(esc_html__('normal', 'buzzblog'), esc_html__('modern', 'buzzblog'))
			),
	),
);

 $buzzblog_meta_box_gallery = array(
	'id' => 'buzzblog-meta-box-gallery',
	'title' =>  esc_html__('Gallery Settings', 'buzzblog'),
	'page' => 'post',
	'context' => 'normal',
	'priority' => 'high',
	'fields' => array(
		array( "name" => esc_html__('Gallery type','buzzblog'),
				"desc" => esc_html__('Choose gallery type.','buzzblog'),
				"id" => "buzzblog_gallery_format",
				"type" => "select",
				"std" => esc_html__('-=set slideshow type=-', 'buzzblog'), 
				"options" => array(esc_html__('-=set slideshow type=-', 'buzzblog'), esc_html__('slideshow', 'buzzblog'), esc_html__('grid', 'buzzblog'))
			),
		array( "name" => esc_html__('Row Height','buzzblog'),
				"desc" => esc_html__('The preferred height of rows in pixel.','buzzblog'),
				"id" => "buzzblog_gallery_targetheight",
				"type" => "text",
				"std" => "200"
			),
		array( "name" => esc_html__('Margins','buzzblog'),
				"desc" => esc_html__('Decide the margins between the images. This only works with grid type gallery format.','buzzblog'),
				"id" => "buzzblog_gallery_margins",
				"type" => "text",
				"std" => "10"
			),
		array( "name" => esc_html__('Randomize','buzzblog'),
				"desc" => esc_html__('Automatically randomize or not the order of photos. This only works with grid type gallery format.','buzzblog'),
				"id" => "buzzblog_gallery_randomize",
				"type" => "select",
				"std" => esc_html__('false', 'buzzblog'),
				"options" => array(esc_html__('false', 'buzzblog'), esc_html__('true', 'buzzblog')) 
			),
		array( "name" => esc_html__('Captions','buzzblog'),
				"desc" => esc_html__('Decide if you want to show the caption or not, that appears when your mouse is over the image. This only works with grid type gallery format.','buzzblog'),
				"id" => "buzzblog_gallery_captions",
				"type" => "select",
				"std" => esc_html__('true', 'buzzblog'),
				"options" => array(esc_html__('true', 'buzzblog'), esc_html__('false', 'buzzblog'))
			),
		array( "name" => esc_html__('Featured image','buzzblog'),
				"desc" => esc_html__('Do you want to show gallery only in the single post page ?','buzzblog'),
				"id" => "buzzblog_gallery_featured",
				"type" => "select",
				"std" => esc_html__('false', 'buzzblog'),
				"options" => array(esc_html__('false', 'buzzblog'), esc_html__('true', 'buzzblog'))
			)
	),	
);

$buzzblog_meta_box_audio = array(
	'id' => 'buzzblog-meta-box-audio',
	'title' =>  esc_html__('Audio Settings', 'buzzblog'),
	'page' => 'post',
	'context' => 'normal',
	'priority' => 'high',
	'fields' => array(
		array( "name" => esc_html__('Title','buzzblog'),
				"desc" => esc_html__('Input the audio title (for playlist).','buzzblog'),
				"id" => "buzzblog_audio_title",
				"type" => "text",
				"std" => ""
			),
		array( "name" => esc_html__('Artist','buzzblog'),
				"desc" => esc_html__('Input the audio artist (for playlist).','buzzblog'),
				"id" => "buzzblog_audio_artist",
				"type" => "text",
				"std" => ""
			),
		array( "name" => esc_html__('Audio URL','buzzblog'),
				"desc" => esc_html__('Input the audio URL.','buzzblog'),
				"id" => "buzzblog_audio_url",
				"type" => "text",
				"std" => ""
			),
		array( "name" => esc_html__('Embedded Code','buzzblog'),
				"desc" => esc_html__('You can include embedded code from soundcloud.com here. Attention! This code overwrite your audio URL(s).','buzzblog'),
				"id" => "buzzblog_audio_embed",
				"type" => "textarea",
				"std" => ""
			)
	),	
);

$buzzblog_meta_box_video = array(
	'id' => 'buzzblog-meta-box-video',
	'title' =>  esc_html__('Video Settings', 'buzzblog'),
	'page' => 'post',
	'context' => 'normal',
	'priority' => 'high',
	'fields' => array(
		array( "name" => esc_html__('Embedded Video Code','buzzblog'),
				"desc" => esc_html__('YouTube Video - Enter the full url to the video page like this: http://youtube.com/watch?v=3H8bnKdf654. Vimeo Video - Enter the full url to the video page like this: http://vimeo.com/9679622','buzzblog'),
				"id" => "buzzblog_video_embed",
				"type" => "text",
				"std" => ""
			)
		)
);
$buzzblog_meta_box_link = array(
	'id' => 'buzzblog-meta-box-link',
	'title' =>  esc_html__('Link Settings', 'buzzblog'),
	'page' => 'post',
	'context' => 'normal',
	'priority' => 'high',
	'fields' => array(
		array( "name" => esc_html__('The url','buzzblog'),
				"desc" => esc_html__('Insert the URL you wish to link to.','buzzblog'),
				"id" => "buzzblog_post_link",
				"type" => "text",
				"std" => ""
			)
		)
);
add_meta_box($buzzblog_meta_box_all['id'], $buzzblog_meta_box_all['title'], 'buzzblog_show_box_all', $buzzblog_meta_box_all['page'], $buzzblog_meta_box_all['context'], $buzzblog_meta_box_all['priority']);
add_meta_box($buzzblog_meta_box_standard['id'], $buzzblog_meta_box_standard['title'], 'buzzblog_show_box_standard', $buzzblog_meta_box_standard['page'], $buzzblog_meta_box_standard['context'], $buzzblog_meta_box_standard['priority']);
	add_meta_box($buzzblog_meta_box_audio['id'], $buzzblog_meta_box_audio['title'], 'buzzblog_show_box_audio', $buzzblog_meta_box_audio['page'], $buzzblog_meta_box_audio['context'], $buzzblog_meta_box_audio['priority']);
	add_meta_box($buzzblog_meta_box_video['id'], $buzzblog_meta_box_video['title'], 'buzzblog_show_box_video', $buzzblog_meta_box_video['page'], $buzzblog_meta_box_video['context'], $buzzblog_meta_box_video['priority']);
	add_meta_box($buzzblog_meta_box_link['id'], $buzzblog_meta_box_link['title'], 'buzzblog_show_box_link', $buzzblog_meta_box_link['page'], $buzzblog_meta_box_link['context'], $buzzblog_meta_box_link['priority']);
	add_meta_box($buzzblog_meta_box_gallery['id'], $buzzblog_meta_box_gallery['title'], 'buzzblog_show_box_gallery', $buzzblog_meta_box_gallery['page'], $buzzblog_meta_box_gallery['context'], $buzzblog_meta_box_gallery['priority']);
}


/*-----------------------------------------------------------------------------------*/
/*	Callback function to show fields in meta box
/*-----------------------------------------------------------------------------------*/
function buzzblog_show_box_all() {
	global $buzzblog_meta_box_all, $post;

	// Use nonce for verification
	echo '<input type="hidden" name="buzzblog_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
 
	echo '<table class="form-table radio-sidebar-option">';
 
	foreach ($buzzblog_meta_box_all['fields'] as $field) {
		// get current post meta data
		$meta = get_post_meta($post->ID, $field['id'], true);

		switch ($field['type']) {
			
						//If radio
			case 'radio':
			
				echo '<tr>',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0;">'. $field['desc'].'</span></label></th>',
				'<td>';
			
				foreach ($field['options'] as $option) {
					
					echo'<label><input type="radio" name="'.$field['id'].'" value="'. $option .'"';
					if ($meta == $option ) { 
						echo ' checked'; 
					}
					echo'><img src="'.get_template_directory_uri().'/includes/images/'.$option.'.png" alt="'. $option .'"  /></label>';
				
				} 
				
				
			
			break;

		}

	}
 
	echo '</table>';
}

function buzzblog_show_box_standard() {
	global $buzzblog_meta_box_standard, $post;

	// Use nonce for verification
	echo '<input type="hidden" name="buzzblog_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
 
	echo '<table class="form-table">';
 
	foreach ($buzzblog_meta_box_standard['fields'] as $field) {
		// get current post meta data
		$meta = get_post_meta($post->ID, $field['id'], true);
		switch ($field['type']) {
			
			//If Select	
			case 'select':
			
				echo '<tr>',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0;">'. $field['desc'].'</span></label></th>',
				'<td>';
			
				echo'<select name="'.$field['id'].'">';
			
				foreach ($field['options'] as $option) {
					
					echo'<option';
					if ($meta == $option ) { 
						echo ' selected="selected"'; 
					}
					echo'>'. $option .'</option>';
				
				} 
				
				echo'</select>';
			
			break;
			

		}

	}
 
	echo '</table>';
}


function buzzblog_show_box_audio() {
	global $buzzblog_meta_box_audio, $post;

	// Use nonce for verification
	echo '<input type="hidden" name="buzzblog_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
 
	echo '<table class="form-table">';
 
	foreach ($buzzblog_meta_box_audio['fields'] as $field) {
		// get current post meta data
		$meta = get_post_meta($post->ID, $field['id'], true);
		switch ($field['type']) {
 
			//If Text		
			case 'text':
			
			echo '<tr>',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">'. $field['desc'].'</span></label></th>',
				'<td>';
			echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '" size="30" style="width:75%; margin-right: 20px; float:left;" />';
			
			break;
			
			//If textarea		
			case 'textarea':
			
			echo '<tr style="border-top:1px solid #eeeeee;">',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style="line-height:18px; display:block; color:#999; margin:5px 0 0 0;">'. $field['desc'].'</span></label></th>',
				'<td>';
			echo '<textarea name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '" rows="8" cols="5" style="width:75%; margin-right: 20px; float:left;">', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '</textarea>';
			
			break;
			
			//If Select	
			case 'select':
			
				echo '<tr>',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0;">'. $field['desc'].'</span></label></th>',
				'<td>';
			
				echo'<select name="'.$field['id'].'">';
			
				foreach ($field['options'] as $option) {
					
					echo'<option';
					if ($meta == $option ) { 
						echo ' selected="selected"'; 
					}
					echo'>'. $option .'</option>';
				
				} 
				
				echo'</select>';
			
			break;

		}

	}
 
	echo '</table>';
}

function buzzblog_show_box_gallery() {
	global $buzzblog_meta_box_gallery, $post;
echo '<div id="buzzblog-pfui-format-gallery-preview" class="buzzblog-pfui-elm-block buzzblog-pfui-elm-block-image ">';
	
	
	echo '<div class="buzzblog-pfui-elm-container">';

		echo '<div class="buzzblog-pfui-gallery-picker">';
			
				// query the gallery images meta
				global $post;
				$images = get_post_meta($post->ID, '_format_gallery_images', true);

				echo '<div class="gallery clearfix">';
				if ($images) {
					foreach ($images as $image) {
						$thumbnail = wp_get_attachment_image_src($image, 'thumbnail');
						
						echo '<span class="image" data-id="' . esc_attr($image) . '" title="'.esc_html__('Image','buzzblog').'"><img src="' . esc_url($thumbnail[0]) . '" alt="" /><span class="close dashicons dashicons-no-alt"></span><a class="dashicons dashicons-edit edit-image image-edit" href="#"></a></span>';
					}
				}
				echo '</div>';
			
			echo '<input type="hidden" id="product_image_gallery" name="_format_gallery_images" value="' . (empty($images) ? "" : implode(',', $images)) . '" />';
			echo '<p class="none"><a href="#" class="button buzzblog-pfui-gallery-button">'.esc_html__('Pick Images','buzzblog').'</a></p>';
		echo '</div>';

	echo '</div></div>';

	// Use nonce for verification
	echo '<input type="hidden" name="buzzblog_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
 
	echo '<table class="form-table">';
 
	foreach ($buzzblog_meta_box_gallery['fields'] as $field) {
		// get current post meta data
		$meta = get_post_meta($post->ID, $field['id'], true);
		switch ($field['type']) {
 
			//If Text		
			case 'text':
			
			echo '<tr>',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">'. $field['desc'].'</span></label></th>',
				'<td>';
			echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '" size="30" style="width:75%; margin-right: 20px; float:left;" />';
			
			break;
			
			//If textarea		
			case 'textarea':
			
			echo '<tr style="border-top:1px solid #eeeeee;">',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style="line-height:18px; display:block; color:#999; margin:5px 0 0 0;">'. $field['desc'].'</span></label></th>',
				'<td>';
			echo '<textarea name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '" rows="8" cols="5" style="width:75%; margin-right: 20px; float:left;">', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '</textarea>';
			
			break;
			
			//If Select	
			case 'select':
			
				echo '<tr>',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0;">'. $field['desc'].'</span></label></th>',
				'<td>';
			
				echo'<select name="'.$field['id'].'">';
			
				foreach ($field['options'] as $option) {
					
					echo'<option';
					if ($meta == $option ) { 
						echo ' selected="selected"'; 
					}
					echo'>'. $option .'</option>';
				
				} 
				
				echo'</select>';
			
			break;

		}

	}
 
	echo '</table>';
}

function buzzblog_show_box_video() {
	global $buzzblog_meta_box_video, $post;

	// Use nonce for verification
	echo '<input type="hidden" name="buzzblog_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
 
	echo '<table class="form-table">';
 
	foreach ($buzzblog_meta_box_video['fields'] as $field) {
		// get current post meta data
		$meta = get_post_meta($post->ID, $field['id'], true);
		switch ($field['type']) {
 
			
			//If Text		
			case 'text':
			
			echo '<tr>',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">'. $field['desc'].'</span></label></th>',
				'<td>';
			echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '" size="30" style="width:75%; margin-right: 20px; float:left;" />';
			
			break;
 
			
			//If textarea		
			case 'textarea':
			
			echo '<tr>',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style="line-height:18px; display:block; color:#999; margin:5px 0 0 0;">'. $field['desc'].'</span></label></th>',
				'<td>';
			echo '<textarea name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '" rows="8" cols="5" style="width:75%; margin-right: 20px; float:left;">', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '</textarea>';
			
			break;
			
			//If Select	
			case 'select':
			
				echo '<tr>',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0;">'. $field['desc'].'</span></label></th>',
				'<td>';
			
				echo'<select name="'.$field['id'].'">';
			
				foreach ($field['options'] as $option) {
					
					echo'<option';
					if ($meta == $option ) { 
						echo ' selected="selected"'; 
					}
					echo'>'. $option .'</option>';
				
				} 
				
				echo'</select>';
			
			break;

		}

	}
 
	echo '</table>';
}

function buzzblog_show_box_link() {
	global $buzzblog_meta_box_link, $post;

	// Use nonce for verification
	echo '<input type="hidden" name="buzzblog_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
 
	echo '<table class="form-table">';
 
	foreach ($buzzblog_meta_box_link['fields'] as $field) {
		// get current post meta data
		$meta = get_post_meta($post->ID, $field['id'], true);
		switch ($field['type']) {
 
			
			//If Text		
			case 'text':
			
			echo '<tr>',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">'. $field['desc'].'</span></label></th>',
				'<td>';
			echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '" size="30" style="width:75%; margin-right: 20px; float:left;" />';
			
			break;

		}

	}
 
	echo '</table>';
}
add_action('save_post', 'buzzblog_save_data');


/*-----------------------------------------------------------------------------------*/
/*	Save data when post is edited
/*-----------------------------------------------------------------------------------*/
 
function buzzblog_save_data($post_id) {
	global $buzzblog_meta_box_all, $buzzblog_meta_box_standard, $buzzblog_meta_box_audio, $buzzblog_meta_box_video, $buzzblog_meta_box_link, $buzzblog_meta_box_gallery;
 
	// verify nonce
	if (!isset($_POST['buzzblog_meta_box_nonce']) || !wp_verify_nonce($_POST['buzzblog_meta_box_nonce'], basename(__FILE__))) {
		return $post_id;
	}
 
	// check autosave
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return $post_id;
	}
 
	// check permissions
	if ('page' == $_POST['post_type']) {
		if (!current_user_can('edit_page', $post_id)) {
			return $post_id;
		}
	} elseif (!current_user_can('edit_post', $post_id)) {
		return $post_id;
	}
 
 		foreach ($buzzblog_meta_box_all['fields'] as $field) {
		$old = get_post_meta($post_id, $field['id'], true);
		$new = (isset($_POST[$field['id']]) ? sanitize_text_field($_POST[$field['id']]) : null);
 
		if ($new && $new != $old) {
			update_post_meta($post_id, $field['id'],$new);
		} elseif ('' == $new && $old) {
			delete_post_meta($post_id, $field['id'], $old);
		}
	}
		foreach ($buzzblog_meta_box_standard['fields'] as $field) {
		$old = get_post_meta($post_id, $field['id'], true);
		$new = (isset($_POST[$field['id']]) ? sanitize_text_field($_POST[$field['id']]) : null);
 
		if ($new && $new != $old) {
			update_post_meta($post_id, $field['id'],$new);
		} elseif ('' == $new && $old) {
			delete_post_meta($post_id, $field['id'], $old);
		}
	}
	
	foreach ($buzzblog_meta_box_audio['fields'] as $field) {
		$old = get_post_meta($post_id, $field['id'], true);
        $new = (isset($_POST[$field['id']]) ? $_POST[$field['id']] : null);
		if ($new && $new != $old) {
			update_post_meta($post_id, $field['id'],stripslashes(htmlspecialchars($new)));
		} elseif ('' == $new && $old) {
			delete_post_meta($post_id, $field['id'], $old);
		}
	}
	
	
	foreach ($buzzblog_meta_box_gallery['fields'] as $field) {
		$old = get_post_meta($post_id, $field['id'], true);
		$new = (isset($_POST[$field['id']]) ? sanitize_text_field($_POST[$field['id']]) : null);
 
		if ($new && $new != $old) {
			update_post_meta($post_id, $field['id'],$new);
		} elseif ('' == $new && $old) {
			delete_post_meta($post_id, $field['id'], $old);
		}
	}
	
	foreach ($buzzblog_meta_box_video['fields'] as $field) {
		$old = get_post_meta($post_id, $field['id'], true);
		$new = (isset($_POST[$field['id']]) ? sanitize_text_field($_POST[$field['id']]) : null);
 
		if ($new && $new != $old) {
			update_post_meta($post_id, $field['id'], $new);
		} elseif ('' == $new && $old) {
			delete_post_meta($post_id, $field['id'], $old);
		}
	}
		foreach ($buzzblog_meta_box_link['fields'] as $field) {
		$old = get_post_meta($post_id, $field['id'], true);
		$new = (isset($_POST[$field['id']]) ? sanitize_text_field($_POST[$field['id']]) : null);
 
		if ($new && $new != $old) {
			update_post_meta($post_id, $field['id'], $new);
		} elseif ('' == $new && $old) {
			delete_post_meta($post_id, $field['id'], $old);
		}
	}
}