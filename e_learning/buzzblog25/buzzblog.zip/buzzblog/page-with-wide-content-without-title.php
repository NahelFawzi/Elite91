<?php
/**
* Template Name: Page With Wide Content Without Title
*/

get_header(); ?>
<?php get_template_part("loop/loop-page"); ?>
<footer class="footer">
<?php get_template_part('wrapper/wrapper-footer'); ?>
</footer>
<?php get_footer(); ?>