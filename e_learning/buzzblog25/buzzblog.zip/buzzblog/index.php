<?php 
get_header(); 
?>
<div class="content-holder clearfix">
<?php if (buzzblog_getVariable('slideshow_enable')=='yes' && buzzblog_getVariable('blog_slideshow')!='inside') { ?> 
<?php if (buzzblog_getVariable('blog_slideshow')=='fullwidth' ) { ?> 
<?php buzzblog_slideshowClass::buzzblog_slideshow(); ?> 
				<?php }else{ ?> 
				<div class="container">
				<div class="row">
				<div class="col-md-12">
<?php buzzblog_slideshowClass::buzzblog_slideshow(); ?>
				</div>
				</div>
				 </div>
				 <?php } } ?> 
<div class="container">
<?php get_template_part('title'); ?>
				<?php if ( is_active_sidebar( 'hs_under_header' ) ) : ?>

				<div class="row">
				<div class="col-md-12">
				<?php dynamic_sidebar("hs_under_header"); ?>
				</div>
				</div>
				
				<?php endif; ?>
                <div class="row main-blog">
				<?php if (buzzblog_getVariable('blog_sidebar_pos')=='right' or buzzblog_getVariable('blog_sidebar_pos')=='') { ?>   
                    <div class="col-md-8" id="content">
					<?php if (buzzblog_getVariable('slideshow_enable')=='yes' && buzzblog_getVariable('blog_slideshow')=='inside' ) {buzzblog_slideshowClass::buzzblog_slideshow();} ?> 
					<?php if (buzzblog_getVariable('promotion_enable')=='yes') { buzzblog_promo_areaslides(); } ?>
                        <?php get_template_part("loop/loop-blog-main"); ?>
						<?php get_template_part('post-template/post-nav'); ?>
                    </div>
					
                 <div class="col-md-4 sidebar <?php if (buzzblog_getVariable('sidebar_sticky')=='stickysidebar') { echo 'sticky-sidebar'; } ?>" id="sidebar">
				 <div class="theiaStickySidebar">
                        <?php dynamic_sidebar("hs_main_sidebar"); ?>
                    </div></div>
					<?php } ?> 
					<?php if (buzzblog_getVariable('blog_sidebar_pos')=='left') { ?> 					
                    <div class="col-md-8 col-md-push-4" id="content">
					<?php if (buzzblog_getVariable('slideshow_enable')=='yes' && buzzblog_getVariable('blog_slideshow')=='inside' ) {buzzblog_slideshowClass::buzzblog_slideshow();} ?> 
					<?php if (buzzblog_getVariable('promotion_enable')=='yes') { buzzblog_promo_areaslides(); } ?>
                        <?php get_template_part("loop/loop-blog-main"); ?>
						<?php get_template_part('post-template/post-nav'); ?>
                    </div>
					
                 <div class="col-md-4 col-md-pull-8 sidebar <?php if (buzzblog_getVariable('sidebar_sticky')=='stickysidebar') { echo 'sticky-sidebar'; } ?> left" id="sidebar">
                        		 <div class="theiaStickySidebar">
                        <?php dynamic_sidebar("hs_main_sidebar"); ?>
                    </div></div>
                   
					<?php } ?> 
					<?php if (buzzblog_getVariable('blog_sidebar_pos')=='full') { ?>   
                    <div class="col-md-12" id="content">
					<?php if (buzzblog_getVariable('slideshow_enable')=='yes' && buzzblog_getVariable('blog_slideshow')=='inside' ) {buzzblog_slideshowClass::buzzblog_slideshow();} ?> 
					<?php if (buzzblog_getVariable('promotion_enable')=='yes') { buzzblog_promo_areaslides(); } ?>
                        <?php get_template_part("loop/loop-blog-main"); ?>
						<?php get_template_part('post-template/post-nav'); ?>
                    </div>
					
					<?php } ?>
					<?php if (buzzblog_getVariable('blog_sidebar_pos')=='masonry2' or buzzblog_getVariable('blog_sidebar_pos')=='masonry3' or buzzblog_getVariable('blog_sidebar_pos')=='masonry4') { ?>   
                    <div class="col-md-12" id="content">
					<?php if (buzzblog_getVariable('slideshow_enable')=='yes' && buzzblog_getVariable('blog_slideshow')=='inside' ) {buzzblog_slideshowClass::buzzblog_slideshow();} ?> 
					<?php if (buzzblog_getVariable('promotion_enable')=='yes') { buzzblog_promo_areaslides(); } ?>
					<div class="grid js-masonry ajax-container row">
                        <?php 
						get_template_part("loop/loop-masonry-blog"); ?>
                    </div>
					<div class="row">
					<div class="col-md-12">
					<?php get_template_part('post-template/post-nav'); ?>
					</div></div>
					</div>
					<?php } ?>
					<?php if (buzzblog_getVariable('blog_sidebar_pos')=='masonry2sideright') { 
					 ?>   
                    <div class="col-md-8" id="content">
					<?php if (buzzblog_getVariable('slideshow_enable')=='yes' && buzzblog_getVariable('blog_slideshow')=='inside' ) {buzzblog_slideshowClass::buzzblog_slideshow();} ?> 
					<?php if (buzzblog_getVariable('promotion_enable')=='yes') { buzzblog_promo_areaslides(); } ?>
					<?php get_template_part('post-template/masonry-stickypost-template'); ?>
					<div class="grid js-masonry ajax-container row">
                         <?php 
						get_template_part("loop/loop-masonry-blog"); ?>
                    </div>
					<?php get_template_part('post-template/post-nav'); ?>
					</div>
                 <div class="col-md-4 sidebar <?php if (buzzblog_getVariable('sidebar_sticky')=='stickysidebar') { echo 'sticky-sidebar'; } ?>" id="sidebar">
                        		 <div class="theiaStickySidebar">
                        <?php dynamic_sidebar("hs_main_sidebar"); ?>
                    </div></div>
                   
					<?php } ?> 
					<?php if (buzzblog_getVariable('blog_sidebar_pos')=='masonry2sideleft') {
                    ?>   
					 <div class="col-md-8 col-md-push-4 " id="content">
					 <?php if (buzzblog_getVariable('slideshow_enable')=='yes' && buzzblog_getVariable('blog_slideshow')=='inside' ) {buzzblog_slideshowClass::buzzblog_slideshow();} ?> 
					<?php if (buzzblog_getVariable('promotion_enable')=='yes') { buzzblog_promo_areaslides(); } ?>
					 <?php get_template_part('post-template/masonry-stickypost-template'); ?>
					<div class="grid js-masonry ajax-container row">
                         <?php 
						
						get_template_part("loop/loop-masonry-blog"); ?>
                    </div>
					<?php get_template_part('post-template/post-nav'); ?>
					</div>
                 <div class="col-md-4 col-md-pull-8 sidebar <?php if (buzzblog_getVariable('sidebar_sticky')=='stickysidebar') { echo 'sticky-sidebar'; } ?> left" id="sidebar">
                        		 <div class="theiaStickySidebar">
                        <?php dynamic_sidebar("hs_main_sidebar"); ?>
                    </div></div>
                  
					<?php } ?> 
					
										<?php if (buzzblog_getVariable('blog_sidebar_pos')=='listpostsideright') { 
					 ?>   
                    <div class="col-md-8" id="content">
					<?php if (buzzblog_getVariable('slideshow_enable')=='yes' && buzzblog_getVariable('blog_slideshow')=='inside' ) {buzzblog_slideshowClass::buzzblog_slideshow();} ?> 
					<?php if (buzzblog_getVariable('promotion_enable')=='yes') { buzzblog_promo_areaslides(); } ?> 
					<div class="list-post ajax-container row">
                         <?php 
						get_template_part("loop/loop-list-post-blog"); ?>
                    </div>
					<?php get_template_part('post-template/post-nav'); ?>
					</div>
                 <div class="col-md-4 sidebar <?php if (buzzblog_getVariable('sidebar_sticky')=='stickysidebar') { echo 'sticky-sidebar'; } ?>" id="sidebar">
                       		 <div class="theiaStickySidebar">
                        <?php dynamic_sidebar("hs_main_sidebar"); ?>
                    </div></div>
                   
					<?php } ?> 
					
					<?php if (buzzblog_getVariable('blog_sidebar_pos')=='listpostsideleft') {
                    ?>   
					 <div class="col-md-8 col-md-push-4 " id="content">
					 <?php if (buzzblog_getVariable('slideshow_enable')=='yes' && buzzblog_getVariable('blog_slideshow')=='inside' ) {buzzblog_slideshowClass::buzzblog_slideshow();} ?> 
<?php if (buzzblog_getVariable('promotion_enable')=='yes') { buzzblog_promo_areaslides(); } ?>
                     <div class="list-post ajax-container row">
                         <?php 
						get_template_part("loop/loop-list-post-blog"); ?>
                    </div>
					<?php get_template_part('post-template/post-nav'); ?>
					</div>
                 <div class="col-md-4 col-md-pull-8 sidebar <?php if (buzzblog_getVariable('sidebar_sticky')=='stickysidebar') { echo 'sticky-sidebar'; } ?> left" id="sidebar">
                        		 <div class="theiaStickySidebar">
                        <?php dynamic_sidebar("hs_main_sidebar"); ?>
                    </div></div>
                   
					<?php } ?> 
					<?php if (buzzblog_getVariable('blog_sidebar_pos')=='listpostfullwidth') {
                    ?>   
					 <div class="col-md-12 " id="content">
					 <?php if (buzzblog_getVariable('slideshow_enable')=='yes' && buzzblog_getVariable('blog_slideshow')=='inside' ) {buzzblog_slideshowClass::buzzblog_slideshow();} ?> 
<?php if (buzzblog_getVariable('promotion_enable')=='yes') { buzzblog_promo_areaslides(); } ?> 
                     <div class="list-post ajax-container fullwidth row">
                         <?php 
						get_template_part("loop/loop-list-post-blog"); ?>
                    </div>
					<?php get_template_part('post-template/post-nav'); ?>
					</div>
					<?php } ?> 
										<?php if (buzzblog_getVariable('blog_sidebar_pos')=='zigzagfullwidth') { ?>   
					 <div class="col-md-12 " id="content">
					  <?php if (buzzblog_getVariable('slideshow_enable')=='yes' && buzzblog_getVariable('blog_slideshow')=='inside' ) {buzzblog_slideshowClass::buzzblog_slideshow();} ?> 
<?php if (buzzblog_getVariable('promotion_enable')=='yes') { buzzblog_promo_areaslides(); } ?>
                     <div class="list-post fullwidth ajax-container row">
                         <?php 
						get_template_part("loop/loop-zigzag-post-blog"); ?>
                    </div>
					<?php get_template_part('post-template/post-nav'); ?>
					</div>
					<?php } ?> 
                      </div>
    </div>	
</div>
<?php //Most commented section  
if (buzzblog_getVariable('most-popular_post')=='yes') { ?> 
	<div class="most-commented" data-stellar-background-ratio="0.5" data-stellar-horizontal-offset="0" data-stellar-vertical-offset="0">
	<div class="container">
				<div class="row">
				<div class="col-md-12"> 
			<?php get_template_part( 'post-template/most-popular-posts' ); ?>
				</div>
				</div>
				</div>
				</div>
<?php }	?> 
<footer class="footer">
<?php get_template_part('wrapper/wrapper-footer'); ?>
</footer>
<?php get_footer(); ?>