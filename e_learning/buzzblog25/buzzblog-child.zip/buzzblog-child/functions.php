<?php
function buzzblog_child_theme_enqueue_styles() {

    $parent_style = 'buzzblog-mainstyle';
    wp_register_style( $parent_style, get_template_directory_uri() . '/style.css', array('bootstrap', 'magnificpopup', 'buzzblog-social-icons'), '1.0', 'all' );
    wp_enqueue_style( $parent_style);
    wp_enqueue_style( 'buzzblog-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style ),
        wp_get_theme()->get('Version')
    );
}
add_action( 'wp_enqueue_scripts', 'buzzblog_child_theme_enqueue_styles' );
?>